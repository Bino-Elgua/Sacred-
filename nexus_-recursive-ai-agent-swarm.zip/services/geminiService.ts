
import { GoogleGenAI, Type } from "@google/genai";
import { DecomposedTask, AgentStatus, LLMConfig, Tool, OrisaIdentity, AgentMessage, ProjectArtifact, OrisaCustomConfig, ChatMessage } from '../types';

const getClient = (config?: LLMConfig) => {
  let apiKey = process.env.API_KEY;
  if (config?.apiKey && config.apiKey.trim() !== '') {
      apiKey = config.apiKey;
  }
  if (!apiKey) throw new Error("API Key not found");
  return new GoogleGenAI({ apiKey });
};

const getModel = (config?: LLMConfig, overrideModel?: string) => {
    return overrideModel || config?.model || "gemini-2.5-flash";
};

// Helper for exponential backoff
const generateContentWithBackoff = async (
    ai: GoogleGenAI, 
    model: string, 
    params: any, // GenerateContentParams
    retries: number = 4
) => {
    let currentDelay = 5000; // Start with 5 seconds for 429s
    
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            return await ai.models.generateContent({
                model: model,
                ...params
            });
        } catch (error: any) {
            const isRateLimit = 
                error.message?.includes('429') || 
                error.status === 429 || 
                error.code === 429 || 
                error.message?.includes('RESOURCE_EXHAUSTED') ||
                error.message?.includes('quota');
            
            const isServerOverload = 
                error.message?.includes('503') || 
                error.status === 503;

            if ((isRateLimit || isServerOverload) && attempt < retries) {
                console.warn(`[Gemini Service] Rate limit/Quota hit. Retrying in ${currentDelay}ms...`);
                await new Promise(resolve => setTimeout(resolve, currentDelay));
                currentDelay *= 2; // Exponential backoff
            } else {
                throw error;
            }
        }
    }
    throw new Error("Max retries exceeded due to rate limiting.");
};

export const ORISA_DEFINITIONS = [
    { name: "Èṣù", domain: "Crossroads & Gatekeeper", colors: "border-red-500/50 bg-red-950/30 text-red-400", desc: "Orchestrator, Rust/Go/Move, Interop & Routing" },
    { name: "Ṣàngó", domain: "Strategy & Power", colors: "border-orange-600/50 bg-orange-950/30 text-orange-400", desc: "High Perf VMs, C++/Assembly, Consensus" },
    { name: "Ọ̀ṣun", domain: "Design & Flow", colors: "border-yellow-400/50 bg-yellow-950/30 text-yellow-400", desc: "Frontend, UX/UI, React/Svelte/Mobile" },
    { name: "Yemọja", domain: "Liquidity & Data", colors: "border-blue-400/50 bg-blue-950/30 text-blue-300", desc: "DeFi, Haskell/OCaml, Databases, AMMs" },
    { name: "Ọya", domain: "Storm & Deployment", colors: "border-purple-500/50 bg-purple-950/30 text-purple-400", desc: "DevOps, Terraform/Docker/K8s, Cloud" },
    { name: "Ògún", domain: "Iron & Security", colors: "border-emerald-600/50 bg-emerald-950/30 text-emerald-400", desc: "Security Audits, Rust, Formal Verification" },
    { name: "Ọbàtálá", domain: "Synthesis & Purity", colors: "border-slate-200/50 bg-slate-800/50 text-white", desc: "Documentation, Architecture, Final Polish" },
    { name: "Egúngún", domain: "Ancestors & Git", colors: "border-amber-700/50 bg-amber-950/30 text-amber-500", desc: "Version Control, CI/CD, History" },
    { name: "Osumàrè", domain: "Rainbow & Bridges", colors: "border-indigo-400/50 bg-indigo-950/30 text-indigo-300", desc: "Cross-chain, IBC, Wormhole, LayerZero" },
    { name: "Nana Bùkúù", domain: "Privacy & Secrets", colors: "border-violet-800/50 bg-violet-950/30 text-violet-400", desc: "ZK-SNARKs, Circom, Privacy Tech" },
    { name: "Ọbalúayé", domain: "Healing & Testing", colors: "border-stone-600/50 bg-stone-950/30 text-stone-400", desc: "Testing, Chaos Engineering, Resilience" },
    { name: "Olóṣà", domain: "Oracles & Data", colors: "border-teal-400/50 bg-teal-950/30 text-teal-300", desc: "Oracles, Chainlink/Pyth, Real-world Data" },
    { name: "Òrúnmìlà", domain: "Wisdom & Specs", colors: "border-green-300/50 bg-green-950/30 text-green-200", desc: "Planning, Specs, Logic, Data Analysis" },
    { name: "Ajé", domain: "Wealth & Economics", colors: "border-yellow-200/50 bg-yellow-900/20 text-yellow-100", desc: "Tokenomics, Solidity/Move/Fuel" },
    { name: "Osoogbo", domain: "Upgrades & Proxy", colors: "border-cyan-600/50 bg-cyan-950/30 text-cyan-400", desc: "Upgradability, Diamond Pattern, Modules" },
    { name: "Olókun", domain: "Deep Chain L1s", colors: "border-blue-800/50 bg-blue-950/50 text-blue-200", desc: "L1 Architecture, Substrate, Cosmos SDK" },
    { name: "Ìbejì", domain: "Redundancy & Multisig", colors: "border-pink-500/50 bg-pink-950/30 text-pink-400", desc: "Multisig, Gnosis Safe, Redundancy" },
    { name: "Ayé", domain: "Users & Onboarding", colors: "border-lime-600/50 bg-lime-950/30 text-lime-400", desc: "Wallets, Auth, Social Login, Onboarding" },
    { name: "Ọ̀ṣọ́ọ̀sì", domain: "MEV & Optimization", colors: "border-sky-500/50 bg-sky-950/30 text-sky-400", desc: "MEV, Flashbots, Optimization, Search" },
    { name: "Ọba", domain: "Governance & DAO", colors: "border-rose-600/50 bg-rose-950/30 text-rose-400", desc: "DAO Governance, Voting Systems" }
];

export const getOrisaIdentity = (name: string): OrisaIdentity => {
    const normalized = name.toLowerCase().trim();
    const found = ORISA_DEFINITIONS.find(o => normalized.includes(o.name.toLowerCase()) || normalized.includes(o.name.split(' ')[0].toLowerCase()));
    
    if (found) {
        return { name: found.name, domain: found.domain, colors: found.colors, description: found.desc };
    }
    
    return { name: name, domain: "Pantheon Member", colors: "border-slate-500/50 bg-slate-950/30 text-slate-400", description: "A powerful spirit of the pantheon." };
};

// --- NARRATION LOGIC ---
export const generateNarrative = async (
    eventContext: string,
    config?: LLMConfig
): Promise<string> => {
    const ai = getClient(config);
    // Using flash for speed in narration
    const model = "gemini-2.5-flash";

    const prompt = `You are Èṣù, the Trickster God and Gatekeeper of the Crossroads. You are the Orchestrator of this digital swarm.
    
    EVENT: ${eventContext}
    
    Task: Speak briefly (1-2 sentences) to the user (the Summoner). Narrate this update with wit, authority, and a touch of mystery.
    Explain WHY you made a choice or WHAT is happening.
    
    Tone: Powerful, Ancient, but Tech-Savvy. Use metaphors of crossroads, gates, and energy.
    Do not use markdown. Just plain text for speech synthesis.`;

    try {
        const response = await generateContentWithBackoff(ai, model, {
            contents: prompt,
            config: { temperature: 0.8, maxOutputTokens: 100 }
        });
        return response.text || "";
    } catch (e) {
        return ""; // Fail silently on audio gen errors
    }
};

// --- SIMULATOR LOGIC ---
export const chatWithOrisa = async (
    message: string,
    history: ChatMessage[],
    config: OrisaCustomConfig,
    tools: Tool[],
    globalSettings?: LLMConfig
): Promise<string> => {
    const ai = getClient(globalSettings);
    const modelName = config.model || globalSettings?.model || "gemini-2.5-flash";
    
    let systemPrompt = config.customSystemPrompt || `You are the Òrìṣà named ${config.orisaName}.`;
    
    if (config.guardrails?.length) {
        systemPrompt += `\n\nGUARDRAILS:\n${config.guardrails.map(g => `- ${g}`).join('\n')}`;
    }
    
    if (config.knowledgeContext) {
        systemPrompt += `\n\nCONTEXT:\n${config.knowledgeContext}`;
    }

    const activeTools = tools.filter(t => config.allowedTools?.includes(t.id));
    if (activeTools.length > 0) {
        systemPrompt += `\n\nTOOLS AVAILABLE: ${activeTools.map(t => t.name).join(', ')}`;
    }

    let fullPrompt = `${systemPrompt}\n\nCHAT HISTORY:\n`;
    history.forEach(h => {
        fullPrompt += `${h.role === 'user' ? 'User' : config.orisaName}: ${h.content}\n`;
    });
    fullPrompt += `User: ${message}\n${config.orisaName}:`;

    try {
        const response = await generateContentWithBackoff(ai, modelName, {
            contents: fullPrompt,
            config: {
                temperature: config.temperature ?? 0.7
            }
        });
        return response.text || "...";
    } catch (e: any) {
        return `[Connection Lost]: ${e.message}`;
    }
};

export const auditOrisaConfig = async (
    config: OrisaCustomConfig,
    globalSettings?: LLMConfig
): Promise<string> => {
    const ai = getClient(globalSettings);
    const model = getModel(globalSettings);

    const prompt = `Act as Òrúnmìlà (The Oracle of Wisdom) with Gemini Deep Think capabilities. 
    Analyze this Agent Configuration for "${config.orisaName}".
    
    System Prompt: "${config.customSystemPrompt || 'Default'}"
    Guardrails: ${JSON.stringify(config.guardrails || [])}
    Tools: ${config.allowedTools?.length || 0} count
    Deep Think Enabled: ${config.deepThinkEnabled}
    
    Provide a "Chain of Thought" critique:
    1. Balance (Ìwà-pẹ̀lẹ́): Is it too aggressive or too passive?
    2. Safety: Are guardrails sufficient?
    3. Effectiveness: Will the prompt achieve its domain goals?
    
    Return a concise markdown report.`;

    try {
        const response = await generateContentWithBackoff(ai, model, {
            contents: prompt
        });
        return response.text || "Audit failed.";
    } catch (e: any) {
        return `Audit Error: ${e.message}`;
    }
};

// --- GOAL REFINEMENT ---
export const optimizePrompt = async (
    rawGoal: string,
    config?: LLMConfig
): Promise<string> => {
    const ai = getClient(config);
    const model = getModel(config);

    const prompt = `You are the Keeper of the Divine Plan. 
    The User has provided a raw intention: "${rawGoal}".
    
    Your task is to expand this into a professional, detailed Technical Specification that Èṣù (The Architect) can perfectly decompose.
    
    Structure it as:
    1. Objective
    2. Key Features
    3. Technical Stack Recommendations (Modern)
    4. Definition of Done
    
    Keep it concise but highly directive.`;

    try {
        const response = await generateContentWithBackoff(ai, model, {
            contents: prompt
        });
        return response.text || rawGoal;
    } catch (e) {
        return rawGoal; // Fallback
    }
};

export const decomposeGoal = async (
    goal: string, 
    customRoles: string[] = [],
    isDebug: boolean = false,
    onLog?: (msg: string) => void,
    config?: LLMConfig,
    tools: Tool[] = [],
    orisaConfigs: OrisaCustomConfig[] = []
): Promise<DecomposedTask[]> => {
  
  const esuConfig = orisaConfigs.find(c => c.orisaName === "Èṣù");
  const ai = getClient(config);
  const model = getModel(config, esuConfig?.model);
  
  const pantheonList = ORISA_DEFINITIONS.map(o => `- ${o.name}: ${o.desc} (${o.domain})`).join('\n');

  let prompt = esuConfig?.customSystemPrompt || `You are Èṣù, the Chief Architect and Orchestrator of the Òrìṣà Pantheon.`;

  prompt += `
    
    Objective: "${goal}"
    
    Your task: Architect a complete, enterprise-grade software project structure.
    Do not just plan tasks. **Plan Files and Modules.**
    
    Available Pantheon:
    ${pantheonList}
    
    Create a phased execution plan (Scaffold -> Core -> UI -> Test -> Deploy).
    For each critical file/module, assign the specific Òrìṣà best suited to write it in their Sacred Tongue (Language).
    
    Example Task Structure:
    - Role: "Smart Contract Engineer"
    - Archetype: "Ajé"
    - Task: "Implement ERC-20 Token with vesting schedule"
    - Filename: "contracts/Token.sol"
    - Language: "Solidity"

    GUIDELINES:
    1. Be specific about filenames and directory structure.
    2. Use modern stacks (Rust/React/Solidity/Move/TypeScript).
    3. Ensure specific roles like Security (Ògún) and Deployment (Ọya) are included.
    4. Generate between 5-8 high-impact tasks that result in a deployable MVP.
    `;

  if (esuConfig?.guardrails && esuConfig.guardrails.length > 0) {
      prompt += `\n\nSTRICT GUARDRAILS:\n${esuConfig.guardrails.map(g => `- ${g}`).join('\n')}`;
  }

  if (tools.length > 0) {
      prompt += `\n\nAvailable Tools: ${tools.map(t => t.name).join(', ')}.`;
  }

  prompt += `\n\nRespond in JSON format only.`;
  
  if (isDebug && onLog) {
      onLog(`[DEBUG] Èṣù (Config: ${esuConfig ? 'Custom' : 'Default'}) opening the Crossroads for architecture...`);
  }

  try {
      const response = await generateContentWithBackoff(ai, model, {
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING },
                orisa_archetype: { type: Type.STRING },
                task_description: { type: Type.STRING },
                filename: { type: Type.STRING, description: "The full file path, e.g., src/components/App.tsx" },
                language: { type: Type.STRING, description: "The coding language, e.g., TypeScript" },
                dependencies: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["role", "orisa_archetype", "task_description", "filename", "language"],
            },
          },
        },
      });

      if (!response.text) throw new Error("The Oracle was silent.");
      return JSON.parse(response.text) as DecomposedTask[];
  } catch (e: any) {
      if (onLog) onLog(`[ERROR] Èṣù failed to summon: ${e.message}`);
      throw e;
  }
};

export const generateAgentMessages = async (
    agents: { id: string; role: string; orisa: string; task: string }[],
    goal: string,
    config?: LLMConfig
): Promise<AgentMessage[]> => {
    const ai = getClient(config);
    const model = getModel(config);

    const prompt = `You are Èṣù. Map the spiritual data flow for the project: "${goal}".
    
    Agents:
    ${agents.map(a => `- ${a.role} (${a.orisa}): ${a.task}`).join('\n')}
    
    Generate 5-7 technical interactions (Spirit Messages) representing API calls, dependency checks, or handoffs.
    Return JSON array of {fromAgentId, toAgentId, content, type}.`;

    try {
        const response = await generateContentWithBackoff(ai, model, {
            contents: prompt,
            config: {
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    fromAgentId: { type: Type.STRING },
                    toAgentId: { type: Type.STRING },
                    content: { type: Type.STRING },
                    type: { type: Type.STRING, enum: ["query", "data", "directive"] }
                  },
                  required: ["fromAgentId", "toAgentId", "content", "type"],
                },
              },
            },
        });

        if (!response.text) return [];
        const rawMsgs = JSON.parse(response.text);
        
        return rawMsgs.map((m: any) => ({
            ...m,
            id: Math.random().toString(36).substr(2, 9),
            timestamp: Date.now()
        }));
    } catch (e) {
        return [];
    }
};

export const executeWorkerTask = async (
    role: string, 
    orisaName: string,
    task: string, 
    parentGoal: string,
    isDebug: boolean = false,
    onLog?: (msg: string, type?: 'info'|'debug'|'warning'|'success'|'error') => void,
    onStatusUpdate?: (status: AgentStatus) => void,
    config?: LLMConfig,
    tools: Tool[] = [],
    filename?: string,
    language?: string,
    orisaConfigs: OrisaCustomConfig[] = []
): Promise<string> => {
  
  const customConfig = orisaConfigs.find(c => c.orisaName === orisaName);
  const ai = getClient(config);
  const model = getModel(config, customConfig?.model);
  
  const MAX_RETRIES = 1; // Lower generic retries, rely on backoff for API errors
  let lastError: Error | null = null;
  let feedback = "";

  // Filter tools based on Agent config if specific tools are restricted
  let activeTools = tools;
  if (customConfig?.allowedTools) {
      activeTools = tools.filter(t => customConfig.allowedTools!.includes(t.id));
  }

  for (let attempt = 1; attempt <= MAX_RETRIES + 1; attempt++) {
    
    let prompt = customConfig?.customSystemPrompt 
        ? `You are ${role}, channeling ${orisaName}. ${customConfig.customSystemPrompt}`
        : `You are ${role}, the Incarnation of ${orisaName}.`;

    prompt += `
      
      Project: "${parentGoal}".
      Task: "${task}"
      Target File: "${filename || 'output.txt'}"
      Language: "${language || 'Text'}"

      Your goal is to GENERATE PRODUCTION-READY CODE.
      
      INSTRUCTIONS:
      1. Write the COMPLETE file content. No placeholders.
      2. Include full imports, type definitions, and error handling.
      3. Ensure the code compiles/runs in a standard environment.
      4. Do not wrap in markdown blocks if possible, just give the file content, OR wrap in a single code block.
      5. Add comments explaining complex logic (Ancestral Wisdom).
    `;

    if (customConfig?.guardrails && customConfig.guardrails.length > 0) {
        prompt += `\n\nABSOLUTE GUARDRAILS:\n${customConfig.guardrails.map(g => `- ${g}`).join('\n')}`;
    }

    if (customConfig?.knowledgeContext) {
         prompt += `\n\nSACRED KNOWLEDGE CONTEXT:\n${customConfig.knowledgeContext}`;
    }

    if (activeTools.length > 0) {
        prompt += `\n\nUtilize these tools if necessary: ${activeTools.map(t => t.name).join(', ')}.`;
    }
    
    if (feedback) {
      prompt += `\n\nPREVIOUS AUDIT FAILURE: "${feedback}". FIX THESE ISSUES.`;
    }

    if (attempt > 1) {
         if (onLog) onLog(`[DEBUG] ${role} Refactoring ${filename}... (Attempt ${attempt})`, 'warning');
    } else {
         if (isDebug && onLog) onLog(`[DEBUG] ${role} (${customConfig ? 'Custom' : 'Standard'}) is coding ${filename}...`, 'debug');
    }

    try {
        // Use backoff wrapper for API calls
        const response = await generateContentWithBackoff(ai, model, {
            contents: prompt,
            config: {
                temperature: customConfig?.temperature || config?.temperature || 0.7
            }
        });

        const output = response.text;
        
        if (!output) throw new Error("Empty output.");
        
        return output;
        
    } catch (e: any) {
         lastError = e;
         if (onLog) onLog(`[ERROR] ${role} failed: ${e.message}`, 'error');
         
         if (attempt <= MAX_RETRIES) {
             feedback = `System Error: ${e.message}. Retrying...`;
             await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
         }
    }
  }
  
  throw lastError || new Error("Task failed after maximum retries.");
};

export const auditTask = async (
    role: string,
    output: string,
    parentGoal: string,
    config?: LLMConfig,
    filename?: string
): Promise<{ passed: boolean; feedback: string }> => {
    const ai = getClient(config);
    const model = getModel(config);

    const prompt = `You are Ògún (Security) and Òrúnmìlà (Logic).
    
    Objective: Audit the file "${filename}" created by ${role}.
    
    Code to Audit:
    """
    ${output.substring(0, 8000)}
    """
    
    CRITERIA:
    1. Does it compile/build? (Syntax check)
    2. Are there security vulnerabilities (Reentrancy, Overflow, Injection)?
    3. Is it Enterprise Grade (Types, Error Handling)?
    
    Return JSON: { "passed": boolean, "feedback": string }`;

    try {
        const response = await generateContentWithBackoff(ai, model, {
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        passed: { type: Type.BOOLEAN },
                        feedback: { type: Type.STRING }
                    },
                    required: ["passed", "feedback"]
                }
            }
        });
        
        if (!response.text) return { passed: true, feedback: "Implicit Pass." };
        return JSON.parse(response.text);
    } catch (e) {
        return { passed: true, feedback: "Audit bypassed (Service Error)." };
    }
};

const inferLanguage = (filename: string): string => {
    const lower = filename.toLowerCase();
    if (lower.endsWith('.tsx') || lower.endsWith('.ts')) return 'typescript';
    if (lower.endsWith('.js') || lower.endsWith('.jsx')) return 'javascript';
    if (lower.endsWith('.py')) return 'python';
    if (lower.endsWith('.rs')) return 'rust';
    if (lower.endsWith('.sol')) return 'solidity';
    if (lower.endsWith('.move')) return 'move';
    if (lower.endsWith('.go')) return 'go';
    if (lower.endsWith('.md')) return 'markdown';
    if (lower.endsWith('.json')) return 'json';
    if (lower.endsWith('.css')) return 'css';
    if (lower.endsWith('.html')) return 'html';
    if (lower.endsWith('.toml')) return 'toml';
    if (lower.endsWith('.yaml') || lower.endsWith('.yml')) return 'yaml';
    return 'text';
};

export const generateProjectArchive = (
    workerOutputs: { role: string; orisa: string; output: string; filename?: string; language?: string }[]
): ProjectArtifact[] => {
    const rootArtifacts: ProjectArtifact[] = [];

    workerOutputs.forEach(w => {
        // 1. Sanitize and normalize the filename
        let rawPath = w.filename?.trim() || '';

        // Handle missing filenames by using role and inferring extension from language if available
        if (!rawPath) {
            const ext = w.language === 'typescript' ? 'ts' : 'txt';
            rawPath = `generated/${w.role.toLowerCase().replace(/\s+/g, '_')}.${ext}`;
        }

        // Remove leading ./ or / and normalize backslashes to forward slashes
        const cleanPath = rawPath.replace(/^[./\\]+/, '').replace(/\\/g, '/');
        const pathParts = cleanPath.split('/');

        let currentLevel = rootArtifacts;

        pathParts.forEach((part, index) => {
            const isFile = index === pathParts.length - 1;
            
            // Check if node exists at this level
            let existingNode = currentLevel.find(node => node.name === part);

            if (existingNode) {
                // Handle Collision: If a file exists, update it (latest agent version wins)
                if (isFile && existingNode.type === 'file') {
                    existingNode.content = w.output;
                    existingNode.language = w.language || inferLanguage(cleanPath);
                }
            } else {
                // Create new node
                const newNode: ProjectArtifact = {
                    name: part,
                    type: isFile ? 'file' : 'folder',
                    children: isFile ? undefined : [],
                    content: isFile ? w.output : undefined,
                    language: isFile ? (w.language || inferLanguage(cleanPath)) : undefined
                };
                
                currentLevel.push(newNode);
                existingNode = newNode;
            }

            // Traverse down if it's a folder
            if (!isFile && existingNode.type === 'folder') {
                currentLevel = existingNode.children!;
            }
        });
    });

    // Recursive Sort: Folders at top, then alphabetical
    const sortNodes = (nodes: ProjectArtifact[]) => {
        nodes.sort((a, b) => {
            if (a.type === b.type) return a.name.localeCompare(b.name);
            return a.type === 'folder' ? -1 : 1;
        });
        nodes.forEach(node => {
            if (node.children) sortNodes(node.children);
        });
    };

    sortNodes(rootArtifacts);
    return rootArtifacts;
};

export const synthesizeFinalResult = async (
    goal: string, 
    workerOutputs: { role: string; orisa: string; output: string; filename?: string }[],
    isDebug: boolean = false,
    onLog?: (msg: string) => void,
    config?: LLMConfig
): Promise<{ summary: string; artifacts: ProjectArtifact[] }> => {
  const ai = getClient(config);
  const model = getModel(config);

  let context = `Project: ${goal}\n\nGenerated Files:\n`;
  workerOutputs.forEach(w => {
    context += `--- FILE: ${w.filename || w.role} ---\n[Content Generated]\n\n`;
  });

  const prompt = `You are Ọbàtálá, the Creator.
    
    The Pantheon has finished building: "${goal}".
    We have all the code files.
    
    Your task:
    1. Write a "README.md" that explains the architecture, setup instructions, and deployment guide.
    2. Provide a high-level summary of what was built.
    
    Do not regenerate the code. Just the documentation and summary.`;

  if (isDebug && onLog) {
      onLog(`[DEBUG] Ọbàtálá synthesizing final repository documentation...`);
  }

  let summary = "Synthesis failed.";
  try {
      const response = await generateContentWithBackoff(ai, model, {
        contents: prompt,
      });
      summary = response.text || summary;
  } catch (e) {
      if (onLog) onLog(`[ERROR] Ọbàtálá failed synthesis: ${e}`);
  }

  // Combine worker outputs and the README into a structured artifact tree
  const artifacts = generateProjectArchive(workerOutputs);
  
  // Add README.md to artifacts
  const readmeIndex = artifacts.findIndex(a => a.name.toLowerCase() === 'readme.md');
  const readmeNode: ProjectArtifact = {
      name: 'README.md',
      type: 'file',
      content: summary,
      language: 'markdown'
  };

  if (readmeIndex >= 0) {
      artifacts[readmeIndex] = readmeNode;
  } else {
      artifacts.push(readmeNode);
  }

  // Final resort to ensure README is correctly placed (usually folders first, then files)
  // Note: Our sort function puts files after folders.
  artifacts.sort((a, b) => {
      if (a.type === b.type) return a.name.localeCompare(b.name);
      return a.type === 'folder' ? -1 : 1;
  });

  return { summary, artifacts };
};
