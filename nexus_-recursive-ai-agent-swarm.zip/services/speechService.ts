
// Simple browser-based TTS service with ElevenLabs integration
// Falls back to browser synthesis if no API key is provided or call fails.

interface VoiceConfig {
    voiceId?: string;
    stability?: number;
    similarityBoost?: number;
    apiKey?: string;
}

class SpeechService {
    private queue: { text: string, config?: VoiceConfig }[] = [];
    private isSpeaking: boolean = false;
    private synth: SpeechSynthesis;
    private voice: SpeechSynthesisVoice | null = null;
    private enabled: boolean = true;
    private audioPlayer: HTMLAudioElement | null = null;

    constructor() {
        this.synth = window.speechSynthesis;
        this.loadVoices();
        if (this.synth.onvoiceschanged !== undefined) {
            this.synth.onvoiceschanged = this.loadVoices.bind(this);
        }
    }

    private loadVoices() {
        const voices = this.synth.getVoices();
        // Fallback voice selection for local TTS
        this.voice = voices.find(v => v.name.includes('Google US English')) || 
                     voices.find(v => v.name.includes('Daniel')) || 
                     voices.find(v => v.name.toLowerCase().includes('male')) ||
                     voices[0];
    }

    public setEnabled(enabled: boolean) {
        this.enabled = enabled;
        if (!enabled) {
            this.cancel();
        }
    }

    public speak(text: string, config?: VoiceConfig) {
        if (!this.enabled) return;
        
        this.queue.push({ text, config });
        this.processQueue();
    }

    private async processQueue() {
        if (this.isSpeaking || this.queue.length === 0) return;

        const item = this.queue.shift();
        if (!item || !item.text) return;

        this.isSpeaking = true;

        // Try ElevenLabs if config is present
        if (item.config?.apiKey && item.config?.voiceId) {
            try {
                await this.speakWithElevenLabs(item.text, item.config);
                this.isSpeaking = false;
                this.processQueue();
                return;
            } catch (e) {
                console.warn("ElevenLabs TTS failed, falling back to browser:", e);
                // Fall through to browser TTS
            }
        }

        // Browser TTS Fallback
        const utterance = new SpeechSynthesisUtterance(item.text);
        if (this.voice) {
            utterance.voice = this.voice;
        }
        
        utterance.pitch = 0.8; 
        utterance.rate = 0.95;
        
        utterance.onend = () => {
            this.isSpeaking = false;
            this.processQueue();
        };

        utterance.onerror = () => {
            this.isSpeaking = false;
            this.processQueue();
        };

        this.synth.speak(utterance);
    }

    private async speakWithElevenLabs(text: string, config: VoiceConfig): Promise<void> {
        if (!config.apiKey || !config.voiceId) throw new Error("Missing ElevenLabs credentials");

        const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${config.voiceId}/stream`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'xi-api-key': config.apiKey
            },
            body: JSON.stringify({
                text,
                model_id: 'eleven_monolingual_v1', // or eleven_turbo_v2
                voice_settings: {
                    stability: config.stability || 0.5,
                    similarity_boost: config.similarityBoost || 0.5
                }
            })
        });

        if (!response.ok) {
            const err = await response.text();
            throw new Error(`ElevenLabs API Error: ${err}`);
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        
        return new Promise((resolve, reject) => {
            const audio = new Audio(url);
            this.audioPlayer = audio;
            
            audio.onended = () => {
                this.audioPlayer = null;
                URL.revokeObjectURL(url);
                resolve();
            };
            
            audio.onerror = (e) => {
                this.audioPlayer = null;
                URL.revokeObjectURL(url);
                reject(e);
            };
            
            audio.play().catch(reject);
        });
    }

    public cancel() {
        this.synth.cancel();
        if (this.audioPlayer) {
            this.audioPlayer.pause();
            this.audioPlayer = null;
        }
        this.queue = [];
        this.isSpeaking = false;
    }
}

export const speechService = new SpeechService();
