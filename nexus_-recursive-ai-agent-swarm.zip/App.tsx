
import React, { useState, useCallback, useEffect } from 'react';
import { Agent, AgentStatus, LogMessage, View, AppSettings, StoredFile, Tool, AgentMessage, ProjectArtifact, OrisaCustomConfig } from './types';
import { decomposeGoal, executeWorkerTask, synthesizeFinalResult, getOrisaIdentity, generateAgentMessages, auditTask, generateNarrative } from './services/geminiService';
import { speechService } from './services/speechService';
import { Sidebar } from './components/Sidebar';
import { SwarmView } from './components/SwarmView';
import { SettingsView } from './components/SettingsView';
import { KnowledgeView } from './components/KnowledgeView';
import { LogsView } from './components/LogsView';
import { OrisaForgeView } from './components/OrisaForgeView';
import { Menu } from 'lucide-react';

const ESU_IDENTITY = getOrisaIdentity("Èṣù");

const INITIAL_MANAGER: Agent = {
  id: 'esu',
  role: 'Lead Architect (CTO)',
  orisa: ESU_IDENTITY,
  status: AgentStatus.IDLE,
  currentAction: 'Awaiting Project Specs...',
  taskDescription: 'Orchestrate the pantheon to achieve the objective.',
  parentId: null,
  output: null,
  color: 'red'
};

const DEFAULT_SETTINGS: AppSettings = {
    llm: {
        provider: 'gemini',
        apiKey: '',
        model: 'gemini-2.5-flash',
        temperature: 0.7
    },
    tools: [
        { id: '1', name: 'Web Search', type: 'api', description: 'General web search capability', enabled: false },
        { id: '2', name: 'Code Execution', type: 'function', description: 'Sandboxed python environment', enabled: false }
    ],
    autoSave: true,
    debugMode: false,
    narratorEnabled: true, // Default on
    maxConcurrentAgents: 2, // LOWERED TO 2 TO PREVENT 429 ERRORS
    contextWindowSize: 128000,
    voiceDefaults: {
        voiceId: '',
        stability: 0.5
    }
};

// Simple p-limit implementation for concurrency control
const pLimit = (concurrency: number) => {
  const queue: (() => Promise<any>)[] = [];
  let activeCount = 0;

  const next = () => {
    activeCount--;
    if (queue.length > 0) {
      queue.shift()!();
    }
  };

  const run = async (fn: () => Promise<any>, resolve: (val: any) => void, reject: (err: any) => void) => {
    activeCount++;
    try {
      const result = await fn();
      resolve(result);
    } catch (err) {
      reject(err);
    } finally {
      next();
    }
  };

  const enqueue = (fn: () => Promise<any>) => {
    return new Promise((resolve, reject) => {
      const action = () => run(fn, resolve, reject);
      if (activeCount < concurrency) {
        run(fn, resolve, reject);
      } else {
        queue.push(action);
      }
    });
  };

  return enqueue;
};

export default function App() {
  const [currentView, setCurrentView] = useState<View>('swarm');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Robust Settings Initialization
  const [settings, setSettings] = useState<AppSettings>(() => {
      try {
          const saved = localStorage.getItem('nexus_settings');
          if (saved) {
              const parsed = JSON.parse(saved);
              return { 
                  ...DEFAULT_SETTINGS, 
                  ...parsed, 
                  tools: parsed.tools || DEFAULT_SETTINGS.tools,
                  llm: { ...DEFAULT_SETTINGS.llm, ...parsed.llm },
                  voiceDefaults: { ...DEFAULT_SETTINGS.voiceDefaults, ...parsed.voiceDefaults },
                  maxConcurrentAgents: parsed.maxConcurrentAgents || 2 // Enforce safe default if missing
              };
          }
      } catch (e) {
          console.error("Failed to parse settings, resetting to default", e);
      }
      return DEFAULT_SETTINGS;
  });
  
  // Data Persistence
  const [storedFiles, setStoredFiles] = useState<StoredFile[]>(() => {
      try { return JSON.parse(localStorage.getItem('nexus_files') || '[]'); } catch { return []; }
  });

  const [orisaConfigs, setOrisaConfigs] = useState<OrisaCustomConfig[]>(() => {
      try { return JSON.parse(localStorage.getItem('nexus_orisa_configs') || '[]'); } catch { return []; }
  });

  const [goal, setGoal] = useState(() => localStorage.getItem('nexus_goal') || '');
  const [customRolesInput, setCustomRolesInput] = useState(() => localStorage.getItem('nexus_custom_roles') || '');
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(() => localStorage.getItem('nexus_session_id'));
  
  // Agents State with Interruption Handling
  const [agents, setAgents] = useState<Agent[]>(() => {
      try {
          const saved = localStorage.getItem('nexus_agents');
          if (saved) {
              const parsed = JSON.parse(saved);
              // If app reloaded while working, mark active agents as interrupted
              return parsed.map((a: Agent) => 
                  (a.status === AgentStatus.WORKING || a.status === AgentStatus.THINKING || a.status === AgentStatus.AUDITING) 
                  ? { ...a, status: AgentStatus.ERROR, currentAction: 'Session Interrupted (Reloaded)' } 
                  : a
              );
          }
          return [INITIAL_MANAGER];
      } catch (e) {
          return [INITIAL_MANAGER];
      }
  });

  const [messages, setMessages] = useState<AgentMessage[]>(() => {
      try { return JSON.parse(localStorage.getItem('nexus_messages') || '[]'); } catch { return []; }
  });

  const [logs, setLogs] = useState<LogMessage[]>(() => {
      try { return JSON.parse(localStorage.getItem('nexus_logs') || '[]'); } catch { return []; }
  });

  const [projectArtifacts, setProjectArtifacts] = useState<ProjectArtifact[]>(() => {
      try { return JSON.parse(localStorage.getItem('nexus_artifacts') || '[]'); } catch { return []; }
  });

  const [finalResult, setFinalResult] = useState<string | null>(() => localStorage.getItem('nexus_final_result'));
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);

  // Persistence Effects
  useEffect(() => localStorage.setItem('nexus_settings', JSON.stringify(settings)), [settings]);
  useEffect(() => localStorage.setItem('nexus_files', JSON.stringify(storedFiles)), [storedFiles]);
  useEffect(() => localStorage.setItem('nexus_orisa_configs', JSON.stringify(orisaConfigs)), [orisaConfigs]);
  useEffect(() => localStorage.setItem('nexus_agents', JSON.stringify(agents)), [agents]);
  useEffect(() => localStorage.setItem('nexus_messages', JSON.stringify(messages)), [messages]);
  useEffect(() => localStorage.setItem('nexus_logs', JSON.stringify(logs)), [logs]);
  useEffect(() => localStorage.setItem('nexus_artifacts', JSON.stringify(projectArtifacts)), [projectArtifacts]);
  useEffect(() => localStorage.setItem('nexus_goal', goal), [goal]);
  useEffect(() => localStorage.setItem('nexus_custom_roles', customRolesInput), [customRolesInput]);
  useEffect(() => {
      if (currentSessionId) localStorage.setItem('nexus_session_id', currentSessionId);
      else localStorage.removeItem('nexus_session_id');
  }, [currentSessionId]);
  useEffect(() => {
      if (finalResult) localStorage.setItem('nexus_final_result', finalResult);
      else localStorage.removeItem('nexus_final_result');
  }, [finalResult]);

  // Initialize Speech Service based on settings
  useEffect(() => {
      speechService.setEnabled(settings.narratorEnabled);
  }, [settings.narratorEnabled]);


  const addLog = useCallback((agentId: string, agentRole: string, message: string, type: LogMessage['type'] = 'info') => {
    setLogs(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      agentId,
      agentRole,
      message,
      type
    }]);
  }, []);

  // Helper for smart narration
  const narrate = useCallback(async (context: string) => {
      if (!settings.narratorEnabled) return;
      const script = await generateNarrative(context, settings.llm);
      
      // Get Èṣù's specific config for Voice ID if available in Forge
      const esuConfig = orisaConfigs.find(c => c.orisaName === "Èṣù");
      const voiceConfig = {
          apiKey: settings.elevenLabsApiKey,
          voiceId: esuConfig?.voiceSettings?.voiceId || settings.voiceDefaults.voiceId,
          stability: esuConfig?.voiceSettings?.stability || settings.voiceDefaults.stability,
          similarityBoost: 0.5 // Default for now
      };

      if (script) speechService.speak(script, voiceConfig);
  }, [settings.narratorEnabled, settings.llm, settings.elevenLabsApiKey, settings.voiceDefaults, orisaConfigs]);

  const updateAgent = (id: string, updates: Partial<Agent>) => {
    setAgents(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
  };

  const handleSaveToKnowledge = (content: string, title?: string, tags?: string[], type: StoredFile['type'] = 'report', specificFolder?: string) => {
      let folderName = specificFolder;
      if (!folderName && currentSessionId) {
          const sessionGoal = goal.length > 30 ? goal.substring(0, 30) + '...' : goal;
          folderName = sessionGoal || 'Untitled Session';
      }
      
      const fileTitle = title || (goal.length > 40 ? goal.substring(0, 40) + '...' : goal);
      const fileTags = tags || ['mission-report'];

      const newFile: StoredFile = {
          id: Math.random().toString(36).substr(2, 9),
          title: fileTitle,
          content: content,
          type: type,
          tags: fileTags,
          createdAt: Date.now(),
          agentCount: agents.length,
          folder: folderName,
          sessionId: currentSessionId || undefined
      };
      setStoredFiles(prev => [newFile, ...prev]);
      addLog('system', 'System', `Saved "${fileTitle}" to Knowledge Base`, 'success');
  };

  const handleUpdateFile = (id: string, updates: Partial<StoredFile>) => {
      setStoredFiles(prev => prev.map(f => f.id === id ? { ...f, ...updates } : f));
  };

  const handleDeleteFile = (id: string) => {
      setStoredFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleUpdateTools = (updatedTools: Tool[]) => {
      setSettings(prev => ({ ...prev, tools: updatedTools }));
  };

  const handleStart = async () => {
    if (!goal.trim()) return;
    
    const newSessionId = Math.random().toString(36).substr(2, 9);
    setCurrentSessionId(newSessionId);

    setIsProcessing(true);
    setFinalResult(null);
    setProjectArtifacts([]);
    setAgents([INITIAL_MANAGER]);
    setMessages([]);
    setLogs([]);
    setSelectedAgentId(null);

    const isDebug = settings.debugMode;
    const enabledTools = settings.tools ? settings.tools.filter(t => t.enabled) : [];

    const logDebug = (agentId: string, role: string, msg: string) => {
        if (isDebug) addLog(agentId, role, msg, 'debug');
    };

    try {
      // PHASE 1: STRATEGY (Èṣù)
      addLog('esu', 'Lead Architect (Èṣù)', `Initializing Plan for: "${goal}"`, 'system');
      updateAgent('esu', { status: AgentStatus.THINKING, currentAction: 'Architecting Solution...' });
      
      // Narration: Intro
      narrate(`I am opening the crossroads to build: ${goal}. Let us see which spirits are needed.`);

      const customRoles = customRolesInput.split(',').map(r => r.trim()).filter(Boolean);
      
      const subTasks = await decomposeGoal(
          goal, 
          customRoles,
          isDebug,
          (msg) => logDebug('esu', 'Lead Architect', msg),
          settings.llm,
          enabledTools,
          orisaConfigs
      );
      
      addLog('esu', 'Lead Architect', `Architecture Defined. Deploying ${subTasks.length} Specialists.`, 'success');
      updateAgent('esu', { status: AgentStatus.WAITING, currentAction: 'Overseeing Development...' });

      // PHASE 2: TEAM ASSEMBLY (Pantheon)
      const newAgents: Agent[] = subTasks.map((task, index) => ({
        id: `specialist-${index}`,
        role: task.role,
        orisa: getOrisaIdentity(task.orisa_archetype),
        status: AgentStatus.IDLE,
        currentAction: 'Standby',
        taskDescription: task.task_description,
        filename: task.filename, 
        language: task.language,
        parentId: 'esu',
        output: null,
        color: 'purple' 
      }));
      
      const auditorAgent: Agent = {
          id: 'auditor',
          role: 'QA & Security Lead',
          orisa: getOrisaIdentity("Òrúnmìlà"),
          status: AgentStatus.IDLE,
          currentAction: 'Monitoring',
          taskDescription: 'Audit code quality, security, and performance.',
          parentId: 'esu',
          output: null,
          color: 'green'
      };

      const obatalaAgent: Agent = {
          id: 'obatala',
          role: 'Product Lead (Synthesizer)',
          orisa: getOrisaIdentity("Ọbàtálá"),
          status: AgentStatus.IDLE,
          currentAction: 'Pending Final Review',
          taskDescription: 'Synthesize final release.',
          parentId: 'esu',
          output: null,
          color: 'white'
      };

      setAgents(prev => [...prev, ...newAgents, auditorAgent, obatalaAgent]);

      // Narration: Team Selection
      const teamSummary = newAgents.map(a => a.orisa.name).join(', ');
      narrate(`I have summoned the pantheon: ${teamSummary}. They will now begin their work.`);

      // PHASE 3: COMMUNICATION MAPPING
      logDebug('esu', 'System', 'Mapping data flow...');
      const interactionPlan = await generateAgentMessages(
          newAgents.map(a => ({ id: a.id, role: a.role, orisa: a.orisa.name, task: a.taskDescription })),
          goal,
          settings.llm
      );
      
      if (interactionPlan.length > 0) {
          for (const msg of interactionPlan) {
              setMessages(prev => [...prev, msg]);
              addLog(msg.fromAgentId, 'Network', `Link established: ${msg.fromAgentId} -> ${msg.toAgentId}`, 'info');
              await new Promise(r => setTimeout(r, 800));
          }
      }

      // PHASE 4: PARALLEL EXECUTION & AUDIT
      const limit = pLimit(settings.maxConcurrentAgents || 2);
      const workerResults: { role: string; orisa: string; output: string; filename?: string }[] = [];

      const tasks = newAgents.map(worker => limit(async () => {
          updateAgent(worker.id, { status: AgentStatus.WORKING, currentAction: `Developing ${worker.filename || 'Module'}...` });
          addLog(worker.id, worker.role, `Starting development of ${worker.filename || 'task'}...`, 'info');
          
          try {
            // Simulate startup delay jitter for realism
            await new Promise(r => setTimeout(r, Math.random() * 2000 + 500));
            
            const output = await executeWorkerTask(
                worker.role,
                worker.orisa.name, 
                worker.taskDescription, 
                goal,
                isDebug,
                (msg, type) => {
                   if (type) addLog(worker.id, worker.role, msg, type);
                   else logDebug(worker.id, worker.role, msg);
                },
                (status) => updateAgent(worker.id, { status }),
                settings.llm,
                enabledTools,
                worker.filename, 
                worker.language,
                orisaConfigs
            );

            // Automatic Audit Phase
            updateAgent(worker.id, { status: AgentStatus.AUDITING, currentAction: 'Undergoing Code Review...' });
            updateAgent('auditor', { status: AgentStatus.WORKING, currentAction: `Auditing ${worker.filename}...` });
            addLog('auditor', 'QA Lead', `Reviewing output from ${worker.role}...`, 'system');

            const auditResult = await auditTask(worker.role, output, goal, settings.llm, worker.filename);
            
            if (auditResult.passed) {
                addLog('auditor', 'QA Lead', `Audit Passed for ${worker.filename}: ${auditResult.feedback}`, 'success');
                updateAgent(worker.id, { status: AgentStatus.COMPLETED, output, currentAction: 'Module Verified.' });
                // Narrate success occasionally
                if (Math.random() > 0.5) narrate(`${worker.orisa.name} has forged ${worker.filename} successfully.`);
            } else {
                addLog('auditor', 'QA Lead', `Audit Issues Found in ${worker.filename}: ${auditResult.feedback}`, 'warning');
                updateAgent(worker.id, { status: AgentStatus.COMPLETED, output, currentAction: 'Completed with Warnings.' });
                narrate(`Ògún found weakness in ${worker.filename}, but we proceed.`);
            }
            updateAgent('auditor', { status: AgentStatus.IDLE, currentAction: 'Monitoring' });

            if (settings.autoSave) {
                handleSaveToKnowledge(
                    output,
                    worker.filename || `Module: ${worker.role}`,
                    ['code-module', worker.role.toLowerCase().replace(/\s+/g, '-'), auditResult.passed ? 'verified' : 'needs-review'],
                    'code'
                );
            }

            workerResults.push({ role: worker.role, orisa: worker.orisa.name, output, filename: worker.filename });

          } catch (error: any) {
            updateAgent(worker.id, { 
                status: AgentStatus.ERROR, 
                currentAction: 'Development Failed.',
                errorMessage: error.message 
            });
            addLog(worker.id, worker.role, `Task failed execution: ${error.message}`, 'error');
            narrate(`${worker.orisa.name} has stumbled. The task failed.`);
            throw error;
          }
      }));

      await Promise.all(tasks);

      // PHASE 5: FINAL SYNTHESIS (Ọbàtálá)
      narrate(`The work is done. Now Ọbàtálá weaves the white cloth of synthesis.`);
      updateAgent('obatala', { status: AgentStatus.THINKING, currentAction: 'Packaging Release...' });
      addLog('obatala', 'Product Lead', 'Initiating final build and synthesis...', 'system');
      
      const result = await synthesizeFinalResult(
          goal, 
          workerResults,
          isDebug,
          (msg) => logDebug('obatala', 'Product Lead', msg),
          settings.llm
      );
      
      setFinalResult(result.summary);
      setProjectArtifacts(result.artifacts);

      updateAgent('obatala', { status: AgentStatus.COMPLETED, currentAction: 'Release Ready.', output: result.summary });
      updateAgent('esu', { status: AgentStatus.COMPLETED, currentAction: 'Project Delivered.' });
      addLog('esu', 'Lead Architect', 'Project Lifecycle Complete. Ready for Deployment.', 'success');
      
      // Final Narration
      narrate(`The creation is complete. You may now deploy the artifact.`);

      if (settings.autoSave) {
          handleSaveToKnowledge(
              JSON.stringify(result.artifacts, null, 2),
              `Archive: ${goal.substring(0, 25)}...`,
              ['project-archive', 'full-release'],
              'archive'
          );
      }

    } catch (error: any) {
      console.error(error);
      addLog('system', 'System', 'Critical System Failure during lifecycle.', 'error');
      updateAgent('esu', { 
          status: AgentStatus.ERROR, 
          currentAction: 'Critical Failure',
          errorMessage: error.message
      });
      narrate(`Chaos has overtaken the ritual. System failure.`);
    } finally {
      setIsProcessing(false);
    }
  };

  const resetSwarm = () => {
    setAgents([INITIAL_MANAGER]);
    setMessages([]);
    setLogs([]);
    setFinalResult(null);
    setProjectArtifacts([]);
    setGoal('');
    setCustomRolesInput('');
    setIsProcessing(false);
    setSelectedAgentId(null);
    setCurrentSessionId(null);
    
    speechService.cancel(); // Stop speaking on reset

    // Clear persistent stores related to session
    localStorage.removeItem('nexus_agents');
    localStorage.removeItem('nexus_messages');
    localStorage.removeItem('nexus_logs');
    localStorage.removeItem('nexus_artifacts');
    localStorage.removeItem('nexus_final_result');
    localStorage.removeItem('nexus_session_id');
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-200 font-sans overflow-hidden">
      
      <button 
        onClick={() => setIsSidebarOpen(true)}
        className="md:hidden absolute top-4 left-4 z-40 p-2 bg-slate-900/80 backdrop-blur border border-slate-800 rounded-lg text-cyan-400 hover:text-white transition-colors"
      >
        <Menu size={24} />
      </button>

      <Sidebar 
        currentView={currentView} 
        onViewChange={setCurrentView} 
        isProcessing={isProcessing}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        narratorEnabled={settings.narratorEnabled}
        onToggleNarrator={() => setSettings(prev => ({...prev, narratorEnabled: !prev.narratorEnabled}))}
      />

      <main className="flex-1 flex flex-col h-full overflow-hidden relative pt-16 md:pt-0 w-full">
        {currentView === 'swarm' && (
            <SwarmView 
                goal={goal} setGoal={setGoal}
                customRolesInput={customRolesInput} setCustomRolesInput={setCustomRolesInput}
                agents={agents} isProcessing={isProcessing}
                isDebugMode={settings.debugMode} setIsDebugMode={(v) => setSettings(prev => ({...prev, debugMode: v}))}
                finalResult={finalResult} handleStart={handleStart} reset={resetSwarm}
                selectedAgentId={selectedAgentId} setSelectedAgentId={setSelectedAgentId}
                onSaveToKnowledge={handleSaveToKnowledge}
                messages={messages}
                llmConfig={settings.llm}
            />
        )}

        {currentView === 'logs' && (
            <LogsView 
                logs={logs} 
                onClearLogs={() => setLogs([])} 
                artifacts={projectArtifacts}
            />
        )}

        {currentView === 'forge' && (
            <OrisaForgeView 
                configs={orisaConfigs}
                onUpdate={setOrisaConfigs}
                tools={settings.tools || []}
                onUpdateTools={handleUpdateTools}
                files={storedFiles}
            />
        )}

        {currentView === 'settings' && (
            <SettingsView settings={settings} onSave={setSettings} />
        )}

        {currentView === 'knowledge' && (
            <KnowledgeView 
                files={storedFiles} 
                onDelete={handleDeleteFile} 
                onUpdate={handleUpdateFile} 
                onUpload={handleSaveToKnowledge}
            />
        )}
      </main>
    </div>
  );
}
