
import React, { useState, useMemo, useRef } from 'react';
import { StoredFile } from '../types';
import { FileText, Search, Trash2, Download, Tag, Clock, Plus, X, Database, Code, Terminal, Folder, ChevronRight, ArrowLeft, UploadCloud, Filter, FileArchive } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import JSZip from 'jszip';

interface KnowledgeViewProps {
  files: StoredFile[];
  onDelete: (id: string) => void;
  onUpdate: (id: string, updates: Partial<StoredFile>) => void;
  onUpload: (content: string, title?: string, tags?: string[], type?: 'report' | 'code' | 'log' | 'archive', folder?: string) => void;
}

export const KnowledgeView: React.FC<KnowledgeViewProps> = ({ files, onDelete, onUpdate, onUpload }) => {
  const [selectedFile, setSelectedFile] = useState<StoredFile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [newTag, setNewTag] = useState('');
  const [activeFolder, setActiveFolder] = useState<string | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'report' | 'code' | 'log' | 'archive'>('all');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Group files by folder
  const folders = useMemo(() => {
      const groups: Record<string, StoredFile[]> = {};
      const uncategorized: StoredFile[] = [];

      files.forEach(f => {
          // 1. Apply Type Filter
          if (filterType !== 'all' && f.type !== filterType) return;

          // 2. Apply Search (Content, Title, Tags)
          if (searchQuery) {
              const query = searchQuery.toLowerCase();
              if (f.title.toLowerCase().includes(query) || 
                  f.tags.some(t => t.toLowerCase().includes(query))) {
                  uncategorized.push(f);
              }
              return;
          }

          if (f.folder) {
              if (!groups[f.folder]) groups[f.folder] = [];
              groups[f.folder].push(f);
          } else {
              uncategorized.push(f);
          }
      });

      // Sort folders by newest file inside
      const sortedFolderNames = Object.keys(groups).sort((a, b) => {
          const newestA = Math.max(...groups[a].map(f => f.createdAt));
          const newestB = Math.max(...groups[b].map(f => f.createdAt));
          return newestB - newestA;
      });

      return { groups, sortedFolderNames, uncategorized };
  }, [files, searchQuery, filterType]);

  const activeFile = selectedFile ? files.find(f => f.id === selectedFile.id) || null : null;

  const handleAddTag = () => {
      if (!activeFile || !newTag.trim()) return;
      if (activeFile.tags.includes(newTag.trim())) return;
      
      onUpdate(activeFile.id, { tags: [...activeFile.tags, newTag.trim()] });
      setNewTag('');
  };

  const handleRemoveTag = (tagToRemove: string) => {
      if (!activeFile) return;
      onUpdate(activeFile.id, { tags: activeFile.tags.filter(t => t !== tagToRemove) });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
          handleAddTag();
      }
  };

  const determineFileType = (filename: string): 'report' | 'code' | 'log' | 'archive' => {
      const lower = filename.toLowerCase();
      if (lower.endsWith('.zip') || lower.endsWith('.tar') || lower.endsWith('.gz')) return 'archive';
      if (lower.endsWith('.log') || lower.endsWith('.txt')) return 'log';
      if (lower.match(/\.(js|ts|tsx|jsx|py|rs|go|java|c|cpp|h|css|html|json|sql|sh|bat|env|yml|yaml|toml|sol|move)$/)) return 'code';
      return 'report'; // Default to report (Markdown/Text)
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(async (file: File) => {
        // Handle ZIP Archives
        if (file.name.toLowerCase().endsWith('.zip')) {
            try {
                const zip = new JSZip();
                const buffer = await file.arrayBuffer();
                const contents = await zip.loadAsync(buffer);
                
                // Create a virtual folder name from the zip filename
                const folderName = file.name.replace(/\.zip$/i, '') + ' (Extracted)';
                
                contents.forEach(async (relativePath, zipEntry) => {
                    if (zipEntry.dir) return;
                    
                    const name = zipEntry.name;
                    // Only extract text-based files to avoid binary garbage
                    const isText = name.match(/\.(txt|md|js|ts|tsx|jsx|json|py|rs|go|java|c|cpp|h|css|html|xml|yaml|yml|log|sh|bat|env|sol|move)$/i);
                    
                    if (isText) {
                        const text = await zipEntry.async("string");
                        let type = determineFileType(name);
                        
                        // Auto-format JSON if possible
                        let finalContent = text;
                        if (name.toLowerCase().endsWith('.json')) {
                            try {
                                finalContent = JSON.stringify(JSON.parse(text), null, 2);
                            } catch (e) {}
                        }

                        onUpload(
                            finalContent,
                            relativePath, // Title reflects path inside zip
                            ['extracted', 'zip-content', type],
                            type,
                            folderName // Group by zip name
                        );
                    }
                });
            } catch (err) {
                console.error("Failed to unzip", err);
                alert("Failed to process ZIP file. Please ensure it is a valid archive.");
            }
        } else {
            // Handle Single Files
            const reader = new FileReader();
            reader.onload = (event) => {
                const content = event.target?.result as string;
                const type = determineFileType(file.name);
                
                // Auto-format JSON
                let finalContent = content;
                if (file.name.toLowerCase().endsWith('.json')) {
                    try {
                        finalContent = JSON.stringify(JSON.parse(content), null, 2);
                    } catch (e) {}
                }

                onUpload(
                    finalContent,
                    file.name,
                    ['uploaded', 'manual-ingest', type],
                    type,
                    'Uploads'
                );
            };
            reader.readAsText(file);
        }
    });
    
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getFileIcon = (type: StoredFile['type']) => {
      switch(type) {
          case 'code': return <Code size={16} className="text-purple-400" />;
          case 'log': return <Terminal size={16} className="text-amber-400" />;
          case 'archive': return <FileArchive size={16} className="text-red-400" />;
          default: return <FileText size={16} className="text-cyan-400" />;
      }
  };

  // --- Mobile Navigation Logic ---
  const showPreview = !!activeFile;

  return (
    <div className="h-full flex flex-col md:flex-row md:gap-6 p-4 md:p-6 overflow-hidden bg-slate-950">
      
      {/* Left Pane: Folders & Files */}
      <div className={`
        flex-col gap-4 w-full md:w-1/3 h-full overflow-hidden
        ${showPreview ? 'hidden md:flex' : 'flex'}
      `}>
        
        {/* Header: Search & Upload */}
        <div className="flex flex-col gap-3 shrink-0">
             <div className="flex gap-2">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                    <input 
                        type="text"
                        placeholder="Search..."
                        value={searchQuery}
                        onChange={(e) => {
                            setSearchQuery(e.target.value);
                            setActiveFolder(null); // Reset folder view on search
                        }}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-cyan-500 outline-none text-slate-200 placeholder-slate-600"
                    />
                </div>
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 rounded-lg transition-colors flex items-center justify-center shadow-lg shadow-cyan-900/20"
                    title="Upload File (Supports .zip extraction)"
                >
                    <UploadCloud size={18} />
                </button>
                <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} multiple accept=".zip,.json,.txt,.md,.js,.ts,.tsx,.py,.rs,.go,.log,.html,.css,.csv" />
             </div>

             {/* Filter Tabs */}
             <div className="flex gap-1 overflow-x-auto scrollbar-hide">
                 {['all', 'report', 'code', 'log', 'archive'].map((type) => (
                     <button
                        key={type}
                        onClick={() => { setFilterType(type as any); setActiveFolder(null); }}
                        className={`px-3 py-1 rounded-full text-xs font-medium capitalize transition-all whitespace-nowrap
                            ${filterType === type 
                                ? 'bg-slate-800 text-white border border-slate-700 shadow' 
                                : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900'}
                        `}
                     >
                         {type}
                     </button>
                 ))}
             </div>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 scrollbar-thin scrollbar-thumb-slate-800">
            
            {/* Breadcrumb / Back to Folders */}
            {activeFolder && !searchQuery && (
                <button 
                    onClick={() => setActiveFolder(null)}
                    className="flex items-center gap-2 text-slate-400 hover:text-white p-2 mb-2 text-sm font-medium transition-colors"
                >
                    <ArrowLeft size={16} /> Back to Folders
                </button>
            )}

            {/* Folder List (Only show if no search and no active folder) */}
            {!searchQuery && !activeFolder && (
                <>
                     <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-2 mt-2 mb-1">
                         {filterType === 'all' ? 'Projects / Sessions' : `${filterType}s`}
                     </h3>
                     {folders.sortedFolderNames.map(folderName => (
                        <div 
                            key={folderName}
                            onClick={() => setActiveFolder(folderName)}
                            className="p-4 rounded-lg border border-slate-800/50 bg-slate-900/30 hover:bg-slate-900 hover:border-cyan-500/30 cursor-pointer transition-all flex items-center justify-between group"
                        >
                            <div className="flex items-center gap-3">
                                <Folder className="text-blue-400" size={20} />
                                <div>
                                    <h3 className="font-medium text-slate-200">{folderName}</h3>
                                    <p className="text-xs text-slate-500">{folders.groups[folderName].length} files</p>
                                </div>
                            </div>
                            <ChevronRight className="text-slate-600 group-hover:text-cyan-400" size={16} />
                        </div>
                     ))}
                     {folders.sortedFolderNames.length === 0 && folders.uncategorized.length === 0 && (
                         <div className="text-center py-10 text-slate-600 italic flex flex-col items-center gap-2">
                             <Database size={32} className="opacity-20" />
                             <span>No content found</span>
                         </div>
                     )}
                </>
            )}

            {/* File List (Show if Search OR Active Folder) */}
            {(searchQuery || activeFolder) && (
                <div className="space-y-2 animate-in fade-in slide-in-from-right-4 duration-300">
                     {/* Header for current view */}
                     {activeFolder && (
                         <div className="px-2 pb-2 border-b border-slate-800/50 mb-2">
                             <h2 className="text-white font-bold flex items-center gap-2">
                                 <Folder size={18} className="text-blue-400"/>
                                 {activeFolder}
                             </h2>
                         </div>
                     )}

                     {/* List Files */}
                     {(activeFolder ? folders.groups[activeFolder] : folders.uncategorized).map(file => (
                        <div 
                            key={file.id}
                            onClick={() => setSelectedFile(file)}
                            className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-lg
                                ${activeFile?.id === file.id 
                                    ? 'bg-cyan-900/20 border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.1)]' 
                                    : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'}
                            `}
                        >
                            <div className="flex items-start gap-3 mb-1">
                                <div className="mt-0.5 shrink-0">{getFileIcon(file.type)}</div>
                                <h3 className="font-medium text-slate-200 truncate flex-1 text-sm">{file.title}</h3>
                            </div>
                            <div className="flex items-center gap-3 text-xs text-slate-500 mb-2 pl-7">
                                <span className="flex items-center gap-1"><Clock size={10} /> {new Date(file.createdAt).toLocaleDateString()}</span>
                            </div>
                            {file.tags.length > 0 && (
                                <div className="flex flex-wrap gap-1 pl-7">
                                    {file.tags.slice(0, 3).map(tag => (
                                        <button 
                                            key={tag} 
                                            onClick={(e) => { e.stopPropagation(); setSearchQuery(tag); }}
                                            className="text-[10px] bg-slate-800 text-cyan-400 px-1.5 py-0.5 rounded flex items-center gap-1 hover:bg-slate-700 hover:text-white transition-colors"
                                        >
                                            <Tag size={8} /> {tag}
                                        </button>
                                    ))}
                                    {file.tags.length > 3 && <span className="text-[10px] text-slate-600">+{file.tags.length - 3}</span>}
                                </div>
                            )}
                        </div>
                     ))}
                     {(activeFolder ? folders.groups[activeFolder] : folders.uncategorized).length === 0 && (
                         <div className="text-center py-8 text-slate-600 text-sm">No files match criteria</div>
                     )}
                </div>
            )}
        </div>
      </div>

      {/* Right Pane: Preview (Desktop) / Full Screen (Mobile) */}
      <div className={`
        flex-1 bg-slate-900/50 border border-slate-800 md:rounded-2xl overflow-hidden flex-col fixed md:static inset-0 z-20 md:z-0 bg-slate-950 md:bg-transparent
        ${showPreview ? 'flex' : 'hidden md:flex'}
      `}>
        {activeFile ? (
            <>
                {/* Header */}
                <div className="bg-slate-950 border-b border-slate-800 p-4 flex flex-col gap-4">
                    {/* Mobile Back Button */}
                    <button 
                        onClick={() => setSelectedFile(null)}
                        className="md:hidden flex items-center gap-2 text-slate-400 hover:text-white mb-2"
                    >
                        <ArrowLeft size={16} /> Back to List
                    </button>

                    <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0">
                            <h2 className="text-lg font-bold text-white flex items-center gap-2 break-words">
                                {getFileIcon(activeFile.type)}
                                <span className="truncate">{activeFile.title}</span>
                            </h2>
                            <div className="flex items-center gap-2 mt-1">
                                <span className="text-xs text-slate-500 font-mono">{activeFile.folder || 'Uncategorized'}</span>
                                <span className="text-slate-700">•</span>
                                <span className="text-xs text-slate-500">{new Date(activeFile.createdAt).toLocaleString()}</span>
                            </div>
                        </div>
                        <div className="flex gap-2 shrink-0">
                            <button 
                                onClick={() => onDelete(activeFile.id)}
                                className="p-2 text-slate-400 hover:text-red-400 hover:bg-red-950/30 rounded-lg transition-colors"
                                title="Delete File"
                            >
                                <Trash2 size={18} />
                            </button>
                            <button 
                                className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-cyan-950/30 rounded-lg transition-colors"
                                title="Download"
                            >
                                <Download size={18} />
                            </button>
                        </div>
                    </div>

                    {/* Tag Manager */}
                    <div className="flex flex-wrap items-center gap-2">
                         {activeFile.tags.map(tag => (
                            <span key={tag} className="group text-xs bg-slate-900 border border-slate-700 text-cyan-400 px-2 py-1 rounded-full flex items-center gap-1">
                                <Tag size={10} /> {tag}
                                <button onClick={() => handleRemoveTag(tag)} className="hover:text-red-400 ml-1">
                                    <X size={10} />
                                </button>
                            </span>
                         ))}
                         <div className="relative flex items-center flex-1 min-w-[100px] max-w-[200px]">
                            <input 
                                value={newTag}
                                onChange={(e) => setNewTag(e.target.value)}
                                onKeyDown={handleKeyDown}
                                placeholder="Add tag..."
                                className="bg-slate-900 border border-slate-800 rounded-full px-3 py-1 text-xs text-slate-200 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none w-full transition-all"
                            />
                            <button 
                                onClick={handleAddTag}
                                className="absolute right-1 text-slate-400 hover:text-cyan-400"
                                disabled={!newTag.trim()}
                            >
                                <Plus size={12} />
                            </button>
                         </div>
                    </div>
                </div>
                
                {/* Content Rendering */}
                <div className="flex-1 overflow-y-auto p-4 md:p-8 bg-slate-950/30">
                    {activeFile.type === 'report' ? (
                         <div className="prose prose-invert max-w-none custom-markdown prose-sm md:prose-base">
                            <ReactMarkdown>{activeFile.content}</ReactMarkdown>
                         </div>
                    ) : activeFile.type === 'code' ? (
                         <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 overflow-x-auto">
                             <pre className="font-mono text-xs md:text-sm text-slate-300">
                                 <code>{activeFile.content}</code>
                             </pre>
                         </div>
                    ) : activeFile.type === 'log' ? (
                        <div className="bg-slate-950/50 p-4 rounded-lg border border-slate-800 overflow-x-auto">
                             <pre className="font-mono text-xs text-amber-500/80 whitespace-pre-wrap leading-relaxed">
                                 {activeFile.content}
                             </pre>
                         </div>
                    ) : (
                         <div className="bg-slate-950/50 p-4 rounded-lg border border-slate-800 overflow-x-auto">
                             <pre className="font-mono text-xs text-slate-400 whitespace-pre-wrap leading-relaxed">
                                 {activeFile.content}
                             </pre>
                         </div>
                    )}
                </div>
            </>
        ) : (
            <div className="flex flex-col items-center justify-center h-full text-slate-600">
                <div className="p-6 bg-slate-900 rounded-full mb-4 animate-pulse">
                    <Database size={32} className="text-slate-500" />
                </div>
                <p className="text-sm text-center px-4">Select a file or upload content to knowledge base.</p>
            </div>
        )}
      </div>
    </div>
  );
};
