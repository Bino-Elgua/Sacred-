
import React, { useState } from 'react';
import { Tool, RagConfig } from '../types';
import { Wrench, Plus, Globe, Database, Code, Trash, Power, FileText, Server } from 'lucide-react';

interface ToolsViewProps {
  tools: Tool[];
  onUpdateTools: (tools: Tool[]) => void;
}

export const ToolsView: React.FC<ToolsViewProps> = ({ tools, onUpdateTools }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newTool, setNewTool] = useState<Partial<Tool>>({ type: 'api', enabled: true });
  // Separate state for RAG config to merge later
  const [ragConfig, setRagConfig] = useState<Partial<RagConfig>>({ sourceType: 'document' });

  const handleAddTool = () => {
    if (!newTool.name) return;
    
    const tool: Tool = {
        id: Math.random().toString(36).substr(2, 9),
        name: newTool.name,
        type: newTool.type as any,
        description: newTool.description || '',
        endpoint: newTool.endpoint || '',
        enabled: true,
        headers: {}
    };

    if (tool.type === 'rag') {
        tool.ragConfig = {
            sourceType: ragConfig.sourceType as 'document' | 'vector_db',
            path: ragConfig.path || '',
            collection: ragConfig.collection
        };
    }

    onUpdateTools([...tools, tool]);
    setIsAdding(false);
    setNewTool({ type: 'api', enabled: true });
    setRagConfig({ sourceType: 'document' });
  };

  const toggleTool = (id: string) => {
      onUpdateTools(tools.map(t => t.id === id ? { ...t, enabled: !t.enabled } : t));
  };

  const deleteTool = (id: string) => {
      onUpdateTools(tools.filter(t => t.id !== id));
  };

  const getIcon = (type: string) => {
      switch (type) {
          case 'webhook': return <Globe className="text-orange-400" />;
          case 'rag': return <Database className="text-blue-400" />;
          case 'function': return <Code className="text-purple-400" />;
          default: return <Wrench className="text-slate-400" />;
      }
  };

  return (
    <div className="h-full p-8 max-w-5xl mx-auto overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
            <h2 className="text-2xl font-bold text-white mb-2">Tools & Integrations</h2>
            <p className="text-slate-400">Extend agent capabilities with external APIs, RAG sources, and Webhooks.</p>
        </div>
        <button 
            onClick={() => setIsAdding(true)}
            className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-all shadow-lg shadow-cyan-900/20"
        >
            <Plus size={18} />
            Add New Tool
        </button>
      </div>

      {isAdding && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-8 animate-in slide-in-from-top-4">
              <h3 className="font-bold text-white mb-4">Configure New Tool</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <input 
                    placeholder="Tool Name"
                    className="bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none"
                    value={newTool.name || ''}
                    onChange={e => setNewTool({...newTool, name: e.target.value})}
                  />
                  <select
                    className="bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none"
                    value={newTool.type}
                    onChange={e => setNewTool({...newTool, type: e.target.value as any})}
                  >
                      <option value="api">External API</option>
                      <option value="webhook">Webhook</option>
                      <option value="rag">RAG Knowledge Source</option>
                      <option value="function">Custom Function</option>
                  </select>
                  
                  <input 
                    placeholder="Description (for Agents)"
                    className="md:col-span-2 bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none"
                    value={newTool.description || ''}
                    onChange={e => setNewTool({...newTool, description: e.target.value})}
                  />

                  {/* Dynamic Fields based on Type */}
                  {newTool.type === 'rag' ? (
                      <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-950/50 rounded-lg border border-slate-800/50">
                          <div className="md:col-span-2 text-xs font-bold text-blue-400 uppercase tracking-wider mb-1">RAG Configuration</div>
                          
                          <select
                            className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
                            value={ragConfig.sourceType}
                            onChange={e => setRagConfig({...ragConfig, sourceType: e.target.value as any})}
                          >
                              <option value="document">Local Document / File</option>
                              <option value="vector_db">Vector Database</option>
                          </select>

                          <input 
                            placeholder={ragConfig.sourceType === 'document' ? "File Path / URL" : "Database Connection URL"}
                            className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-sm"
                            value={ragConfig.path || ''}
                            onChange={e => setRagConfig({...ragConfig, path: e.target.value})}
                          />
                          
                          {ragConfig.sourceType === 'vector_db' && (
                              <input 
                                placeholder="Collection / Index Name"
                                className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
                                value={ragConfig.collection || ''}
                                onChange={e => setRagConfig({...ragConfig, collection: e.target.value})}
                              />
                          )}
                      </div>
                  ) : (
                      <input 
                        placeholder="Endpoint / Connection String"
                        className="md:col-span-2 bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none font-mono text-sm"
                        value={newTool.endpoint || ''}
                        onChange={e => setNewTool({...newTool, endpoint: e.target.value})}
                      />
                  )}
              </div>
              <div className="flex justify-end gap-3">
                  <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-white px-4 py-2">Cancel</button>
                  <button onClick={handleAddTool} className="bg-cyan-600 text-white px-4 py-2 rounded-lg">Save Tool</button>
              </div>
          </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tools.map(tool => (
              <div key={tool.id} className={`relative group bg-slate-900/50 border rounded-xl p-6 transition-all
                  ${tool.enabled ? 'border-slate-700' : 'border-slate-800 opacity-60'}
              `}>
                  <div className="flex items-start justify-between mb-4">
                      <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                          {getIcon(tool.type)}
                      </div>
                      <div className="flex gap-2">
                          <button 
                             onClick={() => toggleTool(tool.id)}
                             className={`p-2 rounded-lg transition-colors ${tool.enabled ? 'text-green-400 hover:bg-green-900/20' : 'text-slate-600 hover:text-slate-400'}`}
                             title={tool.enabled ? 'Disable' : 'Enable'}
                          >
                              <Power size={16} />
                          </button>
                          <button 
                             onClick={() => deleteTool(tool.id)}
                             className="p-2 text-slate-600 hover:text-red-400 rounded-lg hover:bg-red-900/20 transition-colors"
                          >
                              <Trash size={16} />
                          </button>
                      </div>
                  </div>
                  <h3 className="font-bold text-slate-200 mb-1">{tool.name}</h3>
                  <span className="text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded uppercase tracking-wide mb-3 inline-block">{tool.type}</span>
                  <p className="text-sm text-slate-500 line-clamp-2 mb-4 h-10">{tool.description}</p>
                  
                  {tool.type === 'rag' && tool.ragConfig ? (
                      <div className="text-xs text-blue-400 bg-blue-900/10 p-2 rounded border border-blue-900/30 truncate flex items-center gap-2">
                          {tool.ragConfig.sourceType === 'document' ? <FileText size={10}/> : <Server size={10}/>}
                          {tool.ragConfig.path || 'No Source Configured'}
                      </div>
                  ) : (
                      <div className="text-xs font-mono text-slate-600 truncate bg-slate-950 p-2 rounded border border-slate-800">
                          {tool.endpoint || 'No endpoint config'}
                      </div>
                  )}
              </div>
          ))}
      </div>
    </div>
  );
};
