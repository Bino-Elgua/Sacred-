
import React, { useState, useEffect, useRef } from 'react';
import { OrisaCustomConfig, Tool, ChatMessage, RagConfig, StoredFile } from '../types';
import { ORISA_DEFINITIONS, chatWithOrisa, auditOrisaConfig } from '../services/geminiService';
import { Hammer, Sparkles, Shield, Brain, Wrench, Save, Undo, Bot, ScrollText, Eye, Send, Trash2, PlayCircle, Mic, Palette, Menu, X, MessageSquare, Zap, ChevronRight, ChevronLeft, Layout, Box, Code2, Copy, ExternalLink, Database, Globe, Server, Cast, Activity, Download, Play, Power, Trash, Plus, FileText, Users, HardDrive, Clock, Rocket, CloudLightning, RefreshCw, AlertTriangle, ShoppingBag, Coins, Cpu, GitPullRequest, Search, ArrowRightLeft, Link } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface OrisaForgeViewProps {
    configs: OrisaCustomConfig[];
    onUpdate: (newConfigs: OrisaCustomConfig[]) => void;
    tools: Tool[];
    onUpdateTools: (tools: Tool[]) => void;
    files: StoredFile[];
}

// Helper to simulate delay for effect
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const AI_EXTENSIONS = [
    { id: 'langchain', name: 'LangChain', desc: 'Modular chains for RAG & orchestration.', type: 'SDK', geminiOpt: 'Native function calling' },
    { id: 'llamaindex', name: 'LlamaIndex', desc: 'Data connectors for RAG ingestion.', type: 'SDK', geminiOpt: 'Multimodal indexing' },
    { id: 'haystack', name: 'Haystack', desc: 'NLP pipelines for search/RAG.', type: 'SDK', geminiOpt: 'Deep Think query refinement' },
    { id: 'crewai', name: 'CrewAI', desc: 'Role-based multi-agent collaboration.', type: 'SDK', geminiOpt: 'Parallel async execution' },
    { id: 'semantic_kernel', name: 'Semantic Kernel', desc: 'Cross-language orchestration.', type: 'SDK', geminiOpt: 'Backend kernel integration' },
    { id: 'txtai', name: 'txtai', desc: 'All-in-one embeddings & pipelines.', type: 'SDK', geminiOpt: 'Lightweight prototyping' },
    { id: 'langflow', name: 'Langflow', desc: 'Low-code visual builder.', type: 'UI+SDK', geminiOpt: 'Export to function calls' },
    { id: 'dify', name: 'Dify', desc: 'End-to-end LLMOps platform.', type: 'API+SDK', geminiOpt: 'Real-time webhook triggers' },
    { id: 'autogen', name: 'AutoGen', desc: 'Conversational multi-agent framework.', type: 'SDK', geminiOpt: 'Multimodal group chat' },
    { id: 'n8n', name: 'n8n', desc: 'No-code automation workflows.', type: 'UI+API', geminiOpt: 'Node prompt integration' },
];

const RAG_EXTENSIONS = [
    { id: 'vertex_rag', name: 'Vertex AI RAG Engine', desc: 'Managed corpus for session context; multimodal retrieval.', type: 'API', geminiOpt: 'Native corpus integration' },
    { id: 'firecrawl', name: 'Firecrawl', desc: 'Web scraping to RAG; extracts structured data.', type: 'API', geminiOpt: 'Ground prompts with real-time crawls' },
    { id: 'ragflow', name: 'RAGFlow', desc: 'Agentic RAG with reasoning; supports Elasticsearch backend.', type: 'Docker/API', geminiOpt: 'Deep Think query resolution' },
    { id: 'meilisearch', name: 'Meilisearch', desc: 'Fast vector search engine; hybrid ranking.', type: 'API/SDK', geminiOpt: 'Embed via Gemini embeddings' },
    { id: 'pinecone', name: 'Pinecone/FAISS', desc: 'Vector DBs for scalable indexing.', type: 'SDK', geminiOpt: '1M-token queries' },
];

const WEBHOOK_INTEGRATIONS = [
    { id: 'zapier', name: 'Zapier/n8n', desc: 'No-code automations; 5000+ app triggers.', setup: 'Webhook URL + auth', geminiOpt: 'Gemini generates Zap templates.' },
    { id: 'merge', name: 'Merge Unified', desc: 'Normalized APIs for HR/CRM; RAG-grounded data pulls.', setup: 'Unified API key', geminiOpt: 'Auto-normalize for agent inputs.' },
    { id: 'pipedream', name: 'Pipedream/Apify', desc: 'Serverless workflows; scraping + API chaining.', setup: 'Event triggers', geminiOpt: 'Gemini for payload gen.' },
    { id: 'msgraph', name: 'Microsoft Graph', desc: 'Office/Teams integrations; persistent workflows.', setup: 'OAuth via Vertex AI', geminiOpt: 'Multi-agent handoffs.' },
    { id: 'openai', name: 'OpenAI Assistants API', desc: 'Fallback LLM calls; custom GPTs for sub-tasks.', setup: 'API key toggle', geminiOpt: 'Hybrid with Gemini.' },
    { id: 'elevenlabs', name: 'ElevenLabs', desc: 'TTS for agent outputs; voice synthesis on webhook.', setup: 'Voice ID + webhook', geminiOpt: 'Multimodal audio export.' },
    { id: 'stripe', name: 'Stripe/Polygon', desc: 'Finance APIs; real-time data for agent decisions.', setup: 'Key + endpoint', geminiOpt: 'Grounded queries via RAG.' }
];

const SWARM_BOOSTERS = [
    { id: 'langsmith', name: 'LangSmith', func: 'Tracing/eval for chains; cost/performance metrics.', integration: 'SDK; Gemini API hooks for traces.' },
    { id: 'langfuse', name: 'Langfuse', func: 'Observability; prompt versioning + debug UI.', integration: 'OpenTelemetry; real-time in Studio.' },
    { id: 'deepeval', name: 'DeepEval', func: 'LLM eval framework; ROUGE/BLEU for outputs.', integration: 'Python in interpreter; auto-run on deploys.' },
    { id: 'uipath', name: 'UiPath', func: 'RPA + AI agents; UI/API automation.', integration: 'API; for legacy system hooks.' },
    { id: 'relevance', name: 'Relevance AI', func: 'Marketing/analytics agents; no-code pipelines.', integration: 'Visual canvas export to Gemini.' }
];

const REAL_TIME_COLLABORATION = [
    { id: 'liveshare', name: 'Live Share Sessions', useCase: 'Multiple humans + agents edit Forge live', integration: 'Google Drive real-time sync', geminiOpt: 'Gemini Live API + WebSockets' },
    { id: 'supabase', name: 'Supabase Realtime DB', useCase: 'Persistent agent memory across sessions', integration: 'Postgres + Realtime', geminiOpt: 'Auto-sync on every agent response' },
    { id: 'redis', name: 'Redis + Momento', useCase: 'Sub-100ms short-term swarm memory', integration: 'In-memory key-value', geminiOpt: 'Gemini function calling for get/set' },
    { id: 'upstash', name: 'Upstash Serverless Redis', useCase: 'Edge-located memory for global swarms', integration: 'Serverless + per-region', geminiOpt: 'Zero-config in Studio via REST' },
    { id: 'orbitdb', name: 'OrbitDB / IPFS', useCase: 'Fully decentralized, permanent swarm memory', integration: 'Peer-to-peer database', geminiOpt: 'On-chain verifiable agent history' },
    { id: 'threadwise', name: 'Thread-wise Memory', useCase: 'Each mission gets its own isolated timeline', integration: 'Automatic threading + summarization', geminiOpt: 'Gemini 1M context for perfect recall' },
    { id: 'humanloop', name: 'Human-in-the-Loop Panel', useCase: 'Pause swarm, edit mid-flight, resume', integration: 'Live comment + approval gates', geminiOpt: 'Deep Think for impact analysis before resume' },
];

const AUTONOMOUS_DEPLOYMENT = [
    { id: 'vercel', platform: 'Vercel', target: 'Frontend + Serverless functions', auth: 'Vercel token in secrets', verify: 'Live URL + screenshot' },
    { id: 'railway', platform: 'Railway / Fly.io', target: 'Full-stack apps + databases', auth: 'API token', verify: 'Health check + latency metrics' },
    { id: 'cloudflare', platform: 'Cloudflare Pages/Workers', target: 'Edge functions + static sites', auth: 'API token', verify: 'Global latency map' },
    { id: 'render', platform: 'Render', target: 'Docker + static sites', auth: 'Service key', verify: 'Auto-rollback on failure' },
    { id: 'github', platform: 'GitHub Actions', target: 'Trigger custom CI/CD workflows', auth: 'PAT + webhook', verify: 'Artifact download + run logs' },
    { id: 'modal', platform: 'Modal / RunPod', target: 'GPU inference endpoints', auth: 'API key', verify: 'Curl test + response time' },
    { id: 'huggingface', platform: 'Hugging Face Spaces', target: 'Gradio/Streamlit demos', auth: 'HF token', verify: 'Live demo iframe' },
    { id: 'arweave', platform: 'Arweave / Permaweb', target: 'Permanent on-chain frontend', auth: 'Wallet connect', verify: 'TX ID + gateway link' },
];

const SELF_HEALING_CAPABILITIES = [
    { id: 'auto_test', name: 'Auto-Unit-Test Generation', mechanism: 'Runs coverage, writes missing tests', freq: 'After every code change' },
    { id: 'deepeval', name: 'DeepEval / Giskard', mechanism: 'LLM-as-judge + adversarial testing', freq: 'Every 3–10 missions' },
    { id: 'mutation', name: 'Mutation Testing', mechanism: 'Injects bugs → sees if swarm catches them', freq: 'Nightly' },
    { id: 'drift', name: 'Prompt Drift Detection', mechanism: 'Compares new outputs vs golden dataset', freq: 'Real-time' },
    { id: 'optimizer', name: 'Cost & Latency Optimizer', mechanism: 'Switches models (Flash ↔ Pro) dynamically', freq: 'Per task' },
    { id: 'redteam', name: 'Ethical Red-Team', mechanism: 'Probes for bias, PII leaks, jailbreaks', freq: 'Every session start' },
    { id: 'documenter', name: 'Auto-Documenter', mechanism: 'Updates README + diagrams from code', freq: 'On every deploy' },
];

const AGENT_MARKETPLACE = [
    { id: 'export', feature: 'One-Click Export', func: 'Package agent as JSON + vector DB snapshot', impl: 'Download + Arweave TX' },
    { id: 'nft', feature: 'Agent NFT Mint', func: 'Mint agent soul on Base / Solana / Tezos', impl: 'Wallet connect in Studio' },
    { id: 'api', feature: 'Pay-per-Call API', func: 'Host agent behind Fastly / Cloudflare', impl: 'Auto-generated OpenAPI spec' },
    { id: 'bounty', feature: 'Bounty Board', func: 'Post tasks → community agents compete', impl: 'Built-in leaderboard' },
    { id: 'reputation', feature: 'Reputation System', func: 'Success rate, cost, speed → ranking', impl: 'On-chain via Tableland' },
    { id: 'fork', feature: 'Fork & Remix', func: 'Clone any public agent and mutate', impl: 'Git-style history' },
];

export const OrisaForgeView: React.FC<OrisaForgeViewProps> = ({ configs, onUpdate, tools = [], onUpdateTools, files = [] }) => {
  const [selectedOrisa, setSelectedOrisa] = useState(ORISA_DEFINITIONS[0].name);
  const [activeTab, setActiveTab] = useState<'essence' | 'guardrails' | 'knowledge' | 'tools' | 'multimodal' | 'extensions' | 'webhooks' | 'marketplace'>('essence');
  const [isLeftPanelOpen, setIsLeftPanelOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isSelfHealingOn, setIsSelfHealingOn] = useState(false);

  // Tool Management State
  const [isAddingTool, setIsAddingTool] = useState(false);
  const [newTool, setNewTool] = useState<Partial<Tool>>({ type: 'api', enabled: true });
  const [ragConfig, setRagConfig] = useState<Partial<RagConfig>>({ sourceType: 'document' });

  // Reflection Core State
  const [reflectionState, setReflectionState] = useState<'idle' | 'reading' | 'proposing' | 'simulating' | 'quorum' | 'committing'>('idle');

  // Current Config State
  const currentConfig = configs.find(c => c.orisaName === selectedOrisa) || {
      orisaName: selectedOrisa,
      customSystemPrompt: '',
      model: 'gemini-2.5-flash',
      temperature: 0.7,
      guardrails: [],
      allowedTools: [],
      knowledgeContext: '',
      deepThinkEnabled: false,
      voiceSettings: { voiceId: '', stability: 0.5, similarityBoost: 0.5 },
      avatarSettings: { imageUrl: '', stylePrompt: '' },
      webhookTriggers: []
  };

  // Simulator State
  const [simMessages, setSimMessages] = useState<ChatMessage[]>([]);
  const [simInput, setSimInput] = useState('');
  const [isSimulating, setIsSimulating] = useState(false);
  const [simEvents, setSimEvents] = useState<string[]>([]);

  // Deep Think State
  const [auditResult, setAuditResult] = useState<string | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);

  const handleUpdate = (updates: Partial<OrisaCustomConfig>) => {
      const newConfigs = [...configs];
      const index = newConfigs.findIndex(c => c.orisaName === selectedOrisa);
      
      if (index >= 0) {
          newConfigs[index] = { ...newConfigs[index], ...updates };
      } else {
          newConfigs.push({ ...currentConfig, ...updates });
      }
      onUpdate(newConfigs);
  };

  const appendToContext = (text: string) => {
      const current = currentConfig.knowledgeContext || '';
      const separator = current.length > 0 ? '\n\n---\n\n' : '';
      handleUpdate({ knowledgeContext: current + separator + text });
  };

  const handleSendMessage = async () => {
      if (!simInput.trim() || isSimulating) return;
      
      const userMsg = { id: Date.now().toString(), role: 'user' as const, content: simInput, timestamp: Date.now() };
      setSimMessages(prev => [...prev, userMsg]);
      setSimInput('');
      setIsSimulating(true);
      setSimEvents([]);

      try {
          // Simulate Antigravity Events
          await delay(600);
          setSimEvents(prev => [...prev, 'spawning_agent']);
          await delay(800);
          if (currentConfig.allowedTools && currentConfig.allowedTools.length > 0) {
             setSimEvents(prev => [...prev, 'using_tools']);
             await delay(800);
          }

          const response = await chatWithOrisa(userMsg.content, simMessages, currentConfig, tools);
          
          setSimMessages(prev => [...prev, {
              id: (Date.now() + 1).toString(),
              role: 'model',
              content: response,
              timestamp: Date.now()
          }]);
      } finally {
          setIsSimulating(false);
          setSimEvents([]);
      }
  };

  const simulateIncomingMessage = async () => {
      if (isSimulating) return;
      setIsSimulating(true);
      const msg = { 
          id: Date.now().toString(), 
          role: 'user' as const, 
          content: `[SYSTEM MESSAGE] Èṣù sends Directive: "Critical Update Required for ${selectedOrisa}. Report status and verify integrity."`, 
          timestamp: Date.now() 
      };
      setSimMessages(prev => [...prev, msg]);
      
      try {
          const response = await chatWithOrisa(msg.content, simMessages, currentConfig, tools);
          setSimMessages(prev => [...prev, {
              id: (Date.now() + 1).toString(),
              role: 'model',
              content: response,
              timestamp: Date.now()
          }]);
      } finally {
          setIsSimulating(false);
      }
  };

  const runAudit = async () => {
      setIsAuditing(true);
      setAuditResult(null);
      try {
          const result = await auditOrisaConfig(currentConfig);
          setAuditResult(result);
      } finally {
          setIsAuditing(false);
      }
  };

  // Helpers for simulation actions
  const simulatePrototype = (toolName: string) => {
      setSimInput(`Generate Python snippet for ${toolName} integration using Gemini 3.`);
  };

  const simulateCodeGen = (toolName: string) => {
    setSimInput(`Generate ingestion script for ${toolName} RAG pipeline.`);
  };

  const simulateTestInSwarm = (toolName: string) => {
      setSimInput(`Spawn a mini-swarm demo using ${toolName} for task routing.`);
  };

  const simulateExportConfig = (toolName: string) => {
      setSimInput(`Generate JSON schema configuration for ${toolName}.`);
  };

  const simulateEval = () => {
      setSimInput(`Run a Deep Think evaluation on the current swarm performance metrics.`);
  };
  
  const simulateStartLiveSession = () => {
      setSimInput(`Initiate a Live Share session with Supabase Realtime sync.`);
  };

  const simulateExportMemory = () => {
      setSimInput(`Export current thread memory to Arweave via IPFS.`);
  };
  
  const simulatePruneThreads = () => {
      setSimInput(`Auto-summarize and archive threads older than 30 days.`);
  };

  const simulateDeployAll = () => {
      setSimInput(`Deploying all artifacts to configured targets...`);
  };

  const simulateAddTarget = () => {
      setSimInput(`Scanning repository for deployable artifacts and suggesting targets...`);
  };

  const simulateRollback = () => {
      setSimInput(`Initiating rollback of last deployment...`);
  };
  
  const simulatePublish = () => {
      setSimInput(`Publishing Agent Soul for ${selectedOrisa} to Marketplace via Arweave...`);
  };

  const simulateEarnMode = () => {
      setSimInput(`Activating Earn Mode: ${selectedOrisa} is now listening for paid bounties.`);
  };

  // Reflection Core Handlers
  const handleReadArchitecture = async () => {
      setReflectionState('reading');
      setSimInput("System Query: Read full architecture state (Agents, Tools, RAG, Webhooks).");
      // Trigger simulation in next tick to allow state update
      setTimeout(() => {
         handleSendMessage().then(() => setReflectionState('idle'));
      }, 100);
  };

  const handleProposeUpgrade = async () => {
      setReflectionState('proposing');
      setSimInput("Deep Think: Propose architectural upgrades based on recent performance metrics and available extensions.");
      setTimeout(() => {
          handleSendMessage().then(() => setReflectionState('idle'));
      }, 100);
  };

  const handleSimulateUpgrade = async () => {
      setReflectionState('simulating');
      setSimInput("Antigravity: specific sandbox simulation of proposed 'Auto-Healing' upgrade.");
      setTimeout(() => {
          handleSendMessage().then(() => setReflectionState('idle'));
      }, 100);
  };

  const handleCommitUpgrade = async () => {
      setReflectionState('quorum');
      setSimInput("Security Alert: Initiating 3-Witness Quorum check for System Upgrade...");
      setTimeout(() => {
          handleSendMessage().then(() => {
              setTimeout(() => setReflectionState('idle'), 2000);
          });
      }, 100);
  };

  const toggleSelfHealing = () => {
      setIsSelfHealingOn(!isSelfHealingOn);
      if (!isSelfHealingOn) {
          setSimInput(`System Alert: Continuous Self-Healing Loop Enabled. Monitoring active agents for drift...`);
      }
  };

  const handleAddTool = () => {
      if (!newTool.name) return;
      
      const tool: Tool = {
          id: Math.random().toString(36).substr(2, 9),
          name: newTool.name,
          type: newTool.type as any,
          description: newTool.description || '',
          endpoint: newTool.endpoint || '',
          enabled: true,
          headers: {}
      };
  
      if (tool.type === 'rag') {
          tool.ragConfig = {
              sourceType: ragConfig.sourceType as 'document' | 'vector_db',
              path: ragConfig.path || '',
              collection: ragConfig.collection
          };
      }
  
      onUpdateTools([...tools, tool]);
      setIsAddingTool(false);
      setNewTool({ type: 'api', enabled: true });
      setRagConfig({ sourceType: 'document' });
  };

  const deleteTool = (id: string) => {
      onUpdateTools(tools.filter(t => t.id !== id));
  };

  const renderEvent = (event: string) => {
      if (event === 'spawning_agent') {
          return (
              <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono animate-pulse my-2">
                  <Zap size={12} /> Spawning Antigravity Instance...
              </div>
          );
      }
      if (event === 'using_tools') {
           return (
              <div className="flex items-center gap-2 text-xs text-purple-400 font-mono animate-pulse my-2">
                  <Wrench size={12} /> Accessing Tools...
              </div>
          );
      }
      return null;
  };

  return (
    <div className="flex h-full w-full bg-slate-950 overflow-hidden relative">
      
      {/* Left Panel: Altar Selector */}
      <div className={`
        bg-slate-950 border-r border-slate-800 flex flex-col z-10 transition-all duration-300 ease-in-out relative
        ${isLeftPanelOpen ? 'w-64' : 'w-0 overflow-hidden border-none'}
      `}>
        <div className="p-4 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-950">
            <div className="flex items-center gap-2 overflow-hidden">
                <Hammer className="text-red-500 shrink-0" size={20} />
                <h2 className="font-bold text-white whitespace-nowrap">Pantheon Altars</h2>
            </div>
            <button onClick={() => setIsLeftPanelOpen(false)} className="text-slate-400 hover:text-white p-1 hover:bg-slate-800 rounded">
                <ChevronLeft size={20} />
            </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {ORISA_DEFINITIONS.map(orisa => (
                <button
                    key={orisa.name}
                    onClick={() => setSelectedOrisa(orisa.name)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-all relative overflow-hidden group
                        ${selectedOrisa === orisa.name 
                            ? `bg-slate-900 border border-slate-700 text-white shadow-lg` 
                            : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'}
                    `}
                >
                    {/* Color Indicator */}
                    <div className={`w-1 h-full absolute left-0 top-0 ${orisa.colors.split(' ')[0].replace('border-', 'bg-')}`} />
                    
                    <div className="relative z-10">
                        <div className="font-bold text-sm">{orisa.name}</div>
                        <div className="text-[10px] opacity-60 truncate">{orisa.domain}</div>
                    </div>
                    {selectedOrisa === orisa.name && <Sparkles size={14} className="ml-auto text-amber-400 animate-pulse" />}
                </button>
            ))}
        </div>
      </div>

      {/* Main Content: Editor */}
      <div className="flex-1 flex flex-col h-full min-w-0 relative bg-slate-950">
         
         {/* LÉO REFLECTION CORE */}
         <div className="bg-slate-950 border-b border-slate-800 p-4 shrink-0 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-900/10 via-transparent to-indigo-900/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 relative z-10">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-500/10 rounded-lg border border-indigo-500/30 shadow-[0_0_15px_rgba(99,102,241,0.2)]">
                        <Cpu size={24} className="text-indigo-400 animate-pulse-slow" />
                    </div>
                    <div>
                        <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                            LÉO REFLECTION CORE
                            <span className="text-[10px] bg-indigo-900/50 text-indigo-300 px-1.5 py-0.5 rounded border border-indigo-700">v1.0.4</span>
                        </h2>
                        <p className="text-[10px] text-slate-400 font-mono">SELF_MODIFY_PERM: <span className="text-emerald-400">GRANTED</span></p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    <button 
                        onClick={handleReadArchitecture}
                        disabled={reflectionState !== 'idle'}
                        className="px-3 py-1.5 bg-slate-900 border border-slate-700 hover:border-indigo-500 text-slate-300 text-xs font-bold uppercase tracking-wide rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                        <Search size={14} /> Read Arch
                    </button>
                    <button 
                        onClick={handleProposeUpgrade}
                        disabled={reflectionState !== 'idle'}
                        className="px-3 py-1.5 bg-slate-900 border border-slate-700 hover:border-purple-500 text-slate-300 text-xs font-bold uppercase tracking-wide rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                        <Sparkles size={14} /> Propose
                    </button>
                    <button 
                        onClick={handleSimulateUpgrade}
                        disabled={reflectionState !== 'idle'}
                        className="px-3 py-1.5 bg-slate-900 border border-slate-700 hover:border-cyan-500 text-slate-300 text-xs font-bold uppercase tracking-wide rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
                    >
                        <PlayCircle size={14} /> Simulate
                    </button>
                    <div className="h-6 w-px bg-slate-800 mx-1" />
                    <button 
                        onClick={handleCommitUpgrade}
                        disabled={reflectionState !== 'idle'}
                        className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 shadow-lg
                            ${reflectionState === 'quorum' 
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500 animate-pulse' 
                                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-900/20'}
                            disabled:opacity-50
                        `}
                    >
                        {reflectionState === 'quorum' ? <Users size={14} /> : <GitPullRequest size={14} />}
                        {reflectionState === 'quorum' ? 'Quorum Check...' : 'Commit Upgrade'}
                    </button>
                </div>
            </div>
         </div>

         {/* Header / Tabs */}
         <div className="h-16 border-b border-slate-800 flex items-center px-4 justify-between shrink-0 bg-slate-950">
             <div className="flex items-center gap-4 overflow-x-auto scrollbar-hide mask-linear-fade">
                {!isLeftPanelOpen && (
                    <button onClick={() => setIsLeftPanelOpen(true)} className="p-2 hover:bg-slate-800 rounded text-slate-400">
                        <Menu size={20} />
                    </button>
                )}
                <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-800 shrink-0">
                    {[
                        { id: 'essence', icon: Brain, label: 'Essence' },
                        { id: 'guardrails', icon: Shield, label: 'Guardrails' },
                        { id: 'knowledge', icon: ScrollText, label: 'Knowledge' },
                        { id: 'tools', icon: Wrench, label: 'Tools' },
                        { id: 'multimodal', icon: Mic, label: 'Multimodal' },
                        { id: 'extensions', icon: Box, label: 'Extensions' },
                        { id: 'webhooks', icon: Globe, label: 'Webhooks' },
                        { id: 'marketplace', icon: ShoppingBag, label: 'Marketplace' }
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id as any)}
                            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider transition-all
                                ${activeTab === tab.id ? 'bg-slate-800 text-white shadow' : 'text-slate-500 hover:text-slate-300'}
                            `}
                        >
                            <tab.icon size={14} /> {tab.label}
                        </button>
                    ))}
                </div>
             </div>
             <div className="flex items-center gap-2 ml-4 shrink-0">
                 <button 
                    className="text-xs bg-slate-900 border border-slate-700 text-slate-300 px-3 py-1.5 rounded flex items-center gap-2 hover:text-white"
                    onClick={() => handleUpdate({})} // Trigger save if needed
                 >
                     <Save size={14} /> Save
                 </button>
             </div>
         </div>

         {/* Tab Content */}
         <div className="flex-1 overflow-y-auto p-6 md:p-10 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black">
            <div className="max-w-4xl mx-auto space-y-8 pb-20">
                
                {activeTab === 'essence' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                        <section>
                            <label className="block text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider">Core System Prompt</label>
                            <div className="relative">
                                <textarea 
                                    value={currentConfig.customSystemPrompt}
                                    onChange={(e) => handleUpdate({ customSystemPrompt: e.target.value })}
                                    className="w-full h-64 bg-slate-900/50 border border-slate-700 rounded-xl p-4 font-mono text-sm text-slate-300 focus:ring-2 focus:ring-cyan-500 outline-none leading-relaxed resize-none"
                                    placeholder={`You are ${selectedOrisa}...`}
                                />
                                <div className="absolute bottom-4 right-4 text-xs text-slate-600 bg-slate-950/80 px-2 py-1 rounded border border-slate-800">
                                    Markdown Supported
                                </div>
                            </div>
                        </section>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <section>
                                <label className="block text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider">LLM Backbone</label>
                                <select 
                                    value={currentConfig.model}
                                    onChange={(e) => handleUpdate({ model: e.target.value })}
                                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-slate-200 outline-none focus:border-cyan-500"
                                >
                                    <option value="gemini-2.5-flash">Gemini 2.5 Flash (Speed)</option>
                                    <option value="gemini-2.5-pro">Gemini 2.5 Pro (Reasoning)</option>
                                    <option value="gemini-ultra">Gemini Ultra (Deep Think)</option>
                                </select>
                            </section>
                            <section>
                                <label className="flex justify-between text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider">
                                    <span>Temperature</span>
                                    <span className="text-cyan-400">{currentConfig.temperature}</span>
                                </label>
                                <input 
                                    type="range" min="0" max="1" step="0.1"
                                    value={currentConfig.temperature}
                                    onChange={(e) => handleUpdate({ temperature: parseFloat(e.target.value) })}
                                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                                />
                            </section>
                        </div>
                    </div>
                )}

                {activeTab === 'guardrails' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                        <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-xl">
                            <div className="flex items-center justify-between mb-4">
                                <h3 className="font-bold text-white flex items-center gap-2">
                                    <Brain className="text-purple-400" size={18} />
                                    Divine Audit (Deep Think)
                                </h3>
                                <button 
                                    onClick={runAudit}
                                    disabled={isAuditing}
                                    className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg shadow-purple-900/20 disabled:opacity-50"
                                >
                                    {isAuditing ? <span className="animate-spin">⟳</span> : <Sparkles size={14} />}
                                    {isAuditing ? 'Divining...' : 'Run Audit'}
                                </button>
                            </div>
                            
                            {auditResult && (
                                <div className="bg-slate-950 p-4 rounded-lg border border-purple-500/30 text-sm text-slate-300 leading-relaxed animate-in fade-in prose prose-invert prose-sm max-w-none">
                                    <ReactMarkdown>{auditResult}</ReactMarkdown>
                                </div>
                            )}
                            {!auditResult && !isAuditing && (
                                <p className="text-sm text-slate-500 italic">Ask the Oracle to analyze your agent's balance and safety.</p>
                            )}
                        </div>

                        <section>
                            <label className="block text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider">Active Guardrails</label>
                            <div className="space-y-2">
                                {currentConfig.guardrails?.map((g, idx) => (
                                    <div key={idx} className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-3 rounded-lg">
                                        <Shield size={16} className="text-emerald-500" />
                                        <input 
                                            value={g}
                                            onChange={(e) => {
                                                const newG = [...(currentConfig.guardrails || [])];
                                                newG[idx] = e.target.value;
                                                handleUpdate({ guardrails: newG });
                                            }}
                                            className="flex-1 bg-transparent outline-none text-sm text-slate-200"
                                        />
                                        <button 
                                            onClick={() => {
                                                const newG = currentConfig.guardrails?.filter((_, i) => i !== idx);
                                                handleUpdate({ guardrails: newG });
                                            }}
                                            className="text-slate-600 hover:text-red-400"
                                        >
                                            <X size={16} />
                                        </button>
                                    </div>
                                ))}
                                <button 
                                    onClick={() => handleUpdate({ guardrails: [...(currentConfig.guardrails || []), ""] })}
                                    className="w-full py-3 border border-dashed border-slate-700 rounded-lg text-slate-500 hover:text-slate-300 hover:border-slate-500 transition-all text-sm flex items-center justify-center gap-2"
                                >
                                    <Shield size={14} /> Add Guardrail
                                </button>
                            </div>
                        </section>
                    </div>
                )}
                
                {activeTab === 'knowledge' && (
                     <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                        <section>
                            <label className="block text-sm font-bold text-slate-400 mb-2 uppercase tracking-wider">Sacred Context (RAG)</label>
                            <textarea 
                                value={currentConfig.knowledgeContext}
                                onChange={(e) => handleUpdate({ knowledgeContext: e.target.value })}
                                className="w-full h-48 bg-slate-900/50 border border-slate-700 rounded-xl p-4 font-mono text-sm text-slate-300 focus:ring-2 focus:ring-cyan-500 outline-none leading-relaxed resize-none"
                                placeholder="Paste relevant documentation, links, or sacred texts here..."
                            />
                        </section>

                        {/* File Pinning */}
                        <section className="bg-slate-900/30 border border-slate-800 rounded-xl p-4">
                            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                                <Link size={14} /> Link Existing Knowledge
                            </h3>
                            {files.length > 0 ? (
                                <div className="flex flex-wrap gap-2 max-h-40 overflow-y-auto">
                                    {files.map(f => (
                                        <button 
                                            key={f.id}
                                            onClick={() => appendToContext(`[Reference: ${f.title}]\n${f.content}`)}
                                            className="text-xs bg-slate-900 border border-slate-700 hover:bg-cyan-900/30 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 px-2 py-1 rounded flex items-center gap-1 transition-colors"
                                            title="Append content to Context"
                                        >
                                            <FileText size={10} /> {f.title}
                                        </button>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-xs text-slate-600 italic">No files in Knowledge Base to link.</div>
                            )}
                        </section>
                        
                        {/* Advanced RAG Extensions */}
                        <section>
                             <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                <Database className="text-blue-400" size={20} /> Advanced RAG Extensions
                             </h3>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                 {RAG_EXTENSIONS.map(ext => (
                                     <div key={ext.id} className="bg-slate-900 border border-slate-800 p-4 rounded-lg hover:border-blue-500/50 transition-colors group">
                                         <div className="flex justify-between items-start mb-2">
                                             <h4 className="font-bold text-slate-200">{ext.name}</h4>
                                             <span className="text-[10px] bg-blue-900/30 text-blue-300 px-2 py-0.5 rounded border border-blue-800">{ext.type}</span>
                                         </div>
                                         <p className="text-xs text-slate-400 mb-3 h-8">{ext.desc}</p>
                                         <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
                                             <Zap size={10} className="text-yellow-500" />
                                             {ext.geminiOpt}
                                         </div>
                                         <div className="mt-3 flex gap-2 opacity-50 group-hover:opacity-100 transition-opacity">
                                             <button className="text-xs bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 px-3 py-1.5 rounded transition-colors" onClick={() => simulateCodeGen(ext.name)}>
                                                 Ingest & Ground
                                             </button>
                                         </div>
                                     </div>
                                 ))}
                             </div>
                        </section>
                    </div>
                )}

                {activeTab === 'tools' && (
                    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                        
                        {/* Tool Creation Section */}
                        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
                            <div className="flex items-center justify-between mb-6">
                                <div>
                                    <h3 className="text-lg font-bold text-white">Global Tool Registry</h3>
                                    <p className="text-slate-400 text-sm">Create and manage tools available to the Pantheon.</p>
                                </div>
                                <button 
                                    onClick={() => setIsAddingTool(!isAddingTool)}
                                    className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition-all shadow-lg shadow-cyan-900/20 text-sm"
                                >
                                    <Plus size={16} />
                                    {isAddingTool ? 'Cancel' : 'Create New Tool'}
                                </button>
                            </div>

                            {isAddingTool && (
                                <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 mb-6 animate-in slide-in-from-top-2">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                        <input 
                                            placeholder="Tool Name"
                                            className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none text-sm"
                                            value={newTool.name || ''}
                                            onChange={e => setNewTool({...newTool, name: e.target.value})}
                                        />
                                        <select
                                            className="bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none text-sm"
                                            value={newTool.type}
                                            onChange={e => setNewTool({...newTool, type: e.target.value as any})}
                                        >
                                            <option value="api">External API</option>
                                            <option value="webhook">Webhook</option>
                                            <option value="rag">RAG Knowledge Source</option>
                                            <option value="function">Custom Function</option>
                                        </select>
                                        
                                        <input 
                                            placeholder="Description (for Agents)"
                                            className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none text-sm"
                                            value={newTool.description || ''}
                                            onChange={e => setNewTool({...newTool, description: e.target.value})}
                                        />

                                        {/* Dynamic Fields based on Type */}
                                        {newTool.type === 'rag' ? (
                                            <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-900/50 rounded-lg border border-slate-800/50">
                                                <div className="md:col-span-2 text-xs font-bold text-blue-400 uppercase tracking-wider mb-1">RAG Configuration</div>
                                                
                                                <select
                                                    className="bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                                                    value={ragConfig.sourceType}
                                                    onChange={e => setRagConfig({...ragConfig, sourceType: e.target.value as any})}
                                                >
                                                    <option value="document">Local Document / File</option>
                                                    <option value="vector_db">Vector Database</option>
                                                </select>

                                                <input 
                                                    placeholder={ragConfig.sourceType === 'document' ? "File Path / URL" : "Database Connection URL"}
                                                    className="bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none font-mono text-xs"
                                                    value={ragConfig.path || ''}
                                                    onChange={e => setRagConfig({...ragConfig, path: e.target.value})}
                                                />
                                                
                                                {ragConfig.sourceType === 'vector_db' && (
                                                    <input 
                                                        placeholder="Collection / Index Name"
                                                        className="md:col-span-2 bg-slate-950 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-blue-500 outline-none text-sm"
                                                        value={ragConfig.collection || ''}
                                                        onChange={e => setRagConfig({...ragConfig, collection: e.target.value})}
                                                    />
                                                )}
                                            </div>
                                        ) : (
                                            <input 
                                                placeholder="Endpoint / Connection String"
                                                className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-slate-200 focus:ring-2 focus:ring-cyan-500 outline-none font-mono text-xs"
                                                value={newTool.endpoint || ''}
                                                onChange={e => setNewTool({...newTool, endpoint: e.target.value})}
                                            />
                                        )}
                                    </div>
                                    <div className="flex justify-end gap-2">
                                        <button onClick={handleAddTool} className="bg-cyan-600 text-white px-4 py-1.5 rounded text-sm">Create</button>
                                    </div>
                                </div>
                            )}
                        </section>

                        {/* Tool List & Assignment */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {tools.map(tool => {
                                const isAllowed = currentConfig.allowedTools?.includes(tool.id);
                                const getIcon = (type: string) => {
                                    switch (type) {
                                        case 'webhook': return <Globe className="text-orange-400" size={18} />;
                                        case 'rag': return <Database className="text-blue-400" size={18} />;
                                        case 'function': return <Code2 className="text-purple-400" size={18} />;
                                        default: return <Wrench className="text-slate-400" size={18} />;
                                    }
                                };

                                return (
                                    <div 
                                        key={tool.id}
                                        className={`relative p-4 rounded-xl border transition-all flex flex-col gap-3
                                            ${isAllowed 
                                                ? 'bg-cyan-900/10 border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.1)]' 
                                                : 'bg-slate-900 border-slate-800 hover:border-slate-700'}
                                        `}
                                    >
                                        <div className="flex items-start justify-between">
                                            <div className="flex items-center gap-3">
                                                <div className="p-2 bg-slate-950 rounded-lg border border-slate-800">
                                                    {getIcon(tool.type)}
                                                </div>
                                                <div>
                                                    <div className="font-bold text-slate-200 text-sm">{tool.name}</div>
                                                    <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded uppercase tracking-wide">{tool.type}</span>
                                                </div>
                                            </div>
                                            <button 
                                                onClick={() => deleteTool(tool.id)}
                                                className="text-slate-600 hover:text-red-400 p-1 rounded hover:bg-red-900/20 transition-colors"
                                                title="Delete Tool Globally"
                                            >
                                                <Trash2 size={16} />
                                            </button>
                                        </div>
                                        
                                        <p className="text-xs text-slate-500 line-clamp-2 h-8">{tool.description}</p>
                                        
                                        {/* Footer Actions */}
                                        <div className="mt-auto pt-3 border-t border-slate-800/50 flex items-center justify-between">
                                             <span className="text-[10px] text-slate-500 font-mono truncate max-w-[150px]">
                                                 {tool.type === 'rag' && tool.ragConfig ? tool.ragConfig.path : tool.endpoint || 'No Endpoint'}
                                             </span>
                                             
                                             <button 
                                                 onClick={() => {
                                                     const current = currentConfig.allowedTools || [];
                                                     const newAllowed = isAllowed 
                                                         ? current.filter(id => id !== tool.id)
                                                         : [...current, tool.id];
                                                     handleUpdate({ allowedTools: newAllowed });
                                                 }}
                                                 className={`text-xs px-3 py-1.5 rounded-lg font-bold transition-colors flex items-center gap-2
                                                     ${isAllowed 
                                                         ? 'bg-cyan-500 text-white hover:bg-cyan-400' 
                                                         : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}
                                                 `}
                                             >
                                                 {isAllowed ? <><CheckCircleIcon size={12} /> Assigned</> : 'Assign to Agent'}
                                             </button>
                                        </div>
                                    </div>
                                );
                            })}
                            {tools.length === 0 && (
                                <div className="col-span-2 text-center py-10 text-slate-500 italic border border-dashed border-slate-800 rounded-xl">
                                    No tools available. Create one above.
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {activeTab === 'multimodal' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
                             <div className="flex items-center gap-2 mb-4">
                                 <Mic className="text-pink-400" size={20} />
                                 <h3 className="text-lg font-bold text-slate-200">Voice Synthesis (ElevenLabs)</h3>
                             </div>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                 <div>
                                     <label className="block text-xs font-bold text-slate-400 mb-2 uppercase">Voice ID</label>
                                     <input 
                                        value={currentConfig.voiceSettings?.voiceId || ''}
                                        onChange={(e) => handleUpdate({ voiceSettings: { ...currentConfig.voiceSettings!, voiceId: e.target.value } })}
                                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200"
                                        placeholder="e.g. 21m00Tcm4TlvDq8ikWAM"
                                     />
                                 </div>
                                 <div>
                                     <label className="block text-xs font-bold text-slate-400 mb-2 uppercase">Stability: {currentConfig.voiceSettings?.stability}</label>
                                     <input 
                                        type="range" min="0" max="1" step="0.1"
                                        value={currentConfig.voiceSettings?.stability || 0.5}
                                        onChange={(e) => handleUpdate({ voiceSettings: { ...currentConfig.voiceSettings!, stability: parseFloat(e.target.value) } })}
                                        className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
                                     />
                                 </div>
                             </div>
                        </section>
                    </div>
                )}

                {activeTab === 'extensions' && (
                    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                         {/* Extension Hub */}
                         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
                             {AI_EXTENSIONS.map(ext => (
                                 <div key={ext.id} className="bg-slate-900 border border-slate-800 p-5 rounded-xl hover:border-indigo-500/50 transition-all group relative overflow-hidden">
                                     <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20">
                                         <Box size={64} />
                                     </div>
                                     <div className="relative z-10">
                                         <div className="flex justify-between items-start mb-2">
                                             <h4 className="font-bold text-white text-lg">{ext.name}</h4>
                                             <span className="text-[10px] bg-indigo-900/30 text-indigo-300 px-2 py-0.5 rounded border border-indigo-800 font-mono">{ext.type}</span>
                                         </div>
                                         <p className="text-sm text-slate-400 mb-4 h-10">{ext.desc}</p>
                                         
                                         <div className="flex items-center gap-2 text-xs text-slate-500 font-mono mb-4">
                                             <Zap size={12} className="text-yellow-500" />
                                             Gemini 3: {ext.geminiOpt}
                                         </div>

                                         <div className="flex gap-2 mt-2">
                                             <button 
                                                onClick={() => simulatePrototype(ext.name)}
                                                className="flex-1 bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-300 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-colors flex items-center justify-center gap-1"
                                                title="Generate Code"
                                             >
                                                 <Code2 size={12} /> Prototype
                                             </button>
                                             <button 
                                                onClick={() => simulateTestInSwarm(ext.name)}
                                                className="flex-1 bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-300 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-colors flex items-center justify-center gap-1"
                                                title="Test in Swarm"
                                             >
                                                 <PlayCircle size={12} /> Test
                                             </button>
                                             <button 
                                                onClick={() => simulateExportConfig(ext.name)}
                                                className="flex-1 bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-300 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wide transition-colors flex items-center justify-center gap-1"
                                                title="Export Config"
                                             >
                                                 <Download size={12} /> Export
                                             </button>
                                         </div>
                                     </div>
                                 </div>
                             ))}
                         </div>

                         {/* Swarm Boosters */}
                         <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-6">
                             <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                 <Activity className="text-emerald-400" size={20} /> 
                                 SWARM BOOSTERS & OBSERVABILITY
                             </h3>
                             <div className="overflow-x-auto">
                                 <table className="w-full text-sm text-left text-slate-400">
                                     <thead className="text-xs text-slate-500 uppercase bg-slate-950/50 border-b border-slate-800">
                                         <tr>
                                             <th className="px-4 py-3">Booster</th>
                                             <th className="px-4 py-3">Function</th>
                                             <th className="px-4 py-3">Integration</th>
                                             <th className="px-4 py-3 text-right">Action</th>
                                         </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-800">
                                         {SWARM_BOOSTERS.map(boost => (
                                             <tr key={boost.id} className="hover:bg-slate-900/50 transition-colors">
                                                 <td className="px-4 py-3 font-bold text-white">{boost.name}</td>
                                                 <td className="px-4 py-3">{boost.func}</td>
                                                 <td className="px-4 py-3 font-mono text-xs">{boost.integration}</td>
                                                 <td className="px-4 py-3 text-right">
                                                     <button 
                                                        onClick={simulateEval}
                                                        className="text-xs bg-slate-800 hover:bg-emerald-600 hover:text-white px-3 py-1 rounded transition-colors"
                                                     >
                                                         Run Eval
                                                     </button>
                                                 </td>
                                             </tr>
                                         ))}
                                     </tbody>
                                 </table>
                             </div>
                         </div>

                         {/* REAL-TIME COLLABORATION & MEMORY LAYER */}
                         <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-6">
                             <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                 <Users className="text-blue-400" size={20} /> 
                                 REAL-TIME COLLABORATION & MEMORY LAYER
                             </h3>
                             <div className="overflow-x-auto">
                                 <table className="w-full text-sm text-left text-slate-400">
                                     <thead className="text-xs text-slate-500 uppercase bg-slate-950/50 border-b border-slate-800">
                                         <tr>
                                             <th className="px-4 py-3">Feature</th>
                                             <th className="px-4 py-3">Universal Use Case</th>
                                             <th className="px-4 py-3">Integration Type</th>
                                             <th className="px-4 py-3">Gemini 3 Optimization</th>
                                         </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-800">
                                         {REAL_TIME_COLLABORATION.map(item => (
                                             <tr key={item.id} className="hover:bg-slate-900/50 transition-colors">
                                                 <td className="px-4 py-3 font-bold text-white">{item.name}</td>
                                                 <td className="px-4 py-3">{item.useCase}</td>
                                                 <td className="px-4 py-3 font-mono text-xs">{item.integration}</td>
                                                 <td className="px-4 py-3 text-xs">{item.geminiOpt}</td>
                                             </tr>
                                         ))}
                                     </tbody>
                                 </table>
                             </div>
                             <div className="mt-4 flex gap-2 justify-end border-t border-slate-800/50 pt-4">
                                 <button 
                                    onClick={simulateStartLiveSession}
                                    className="flex items-center gap-2 text-xs bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 px-3 py-2 rounded transition-colors font-bold uppercase tracking-wide"
                                 >
                                     <Users size={14} /> Start Live Session
                                 </button>
                                 <button 
                                    onClick={simulateExportMemory}
                                    className="flex items-center gap-2 text-xs bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 px-3 py-2 rounded transition-colors font-bold uppercase tracking-wide"
                                 >
                                     <HardDrive size={14} /> Export Memory
                                 </button>
                                 <button 
                                    onClick={simulatePruneThreads}
                                    className="flex items-center gap-2 text-xs bg-slate-800 hover:bg-blue-600 hover:text-white text-slate-300 px-3 py-2 rounded transition-colors font-bold uppercase tracking-wide"
                                 >
                                     <Clock size={14} /> Prune Old Threads
                                 </button>
                             </div>
                         </div>

                         {/* AUTONOMOUS DEPLOYMENT ENGINE */}
                         <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-6">
                             <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                 <Rocket className="text-red-400" size={20} /> 
                                 AUTONOMOUS DEPLOYMENT ENGINE
                             </h3>
                             <div className="overflow-x-auto">
                                 <table className="w-full text-sm text-left text-slate-400">
                                     <thead className="text-xs text-slate-500 uppercase bg-slate-950/50 border-b border-slate-800">
                                         <tr>
                                             <th className="px-4 py-3">Platform</th>
                                             <th className="px-4 py-3">One-Click Deploy Target</th>
                                             <th className="px-4 py-3">Auth Method</th>
                                             <th className="px-4 py-3">Success Verification</th>
                                         </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-800">
                                         {AUTONOMOUS_DEPLOYMENT.map(item => (
                                             <tr key={item.id} className="hover:bg-slate-900/50 transition-colors">
                                                 <td className="px-4 py-3 font-bold text-white">{item.platform}</td>
                                                 <td className="px-4 py-3">{item.target}</td>
                                                 <td className="px-4 py-3 font-mono text-xs">{item.auth}</td>
                                                 <td className="px-4 py-3 text-xs">{item.verify}</td>
                                             </tr>
                                         ))}
                                     </tbody>
                                 </table>
                             </div>
                             <div className="mt-4 flex gap-2 justify-end border-t border-slate-800/50 pt-4">
                                 <button 
                                    onClick={simulateDeployAll}
                                    className="flex items-center gap-2 text-xs bg-slate-800 hover:bg-red-600 hover:text-white text-slate-300 px-3 py-2 rounded transition-colors font-bold uppercase tracking-wide"
                                 >
                                     <Rocket size={14} /> Deploy All Artifacts
                                 </button>
                                 <button 
                                    onClick={simulateAddTarget}
                                    className="flex items-center gap-2 text-xs bg-slate-800 hover:bg-red-600 hover:text-white text-slate-300 px-3 py-2 rounded transition-colors font-bold uppercase tracking-wide"
                                 >
                                     <Plus size={14} /> Add Deploy Target
                                 </button>
                                 <button 
                                    onClick={simulateRollback}
                                    className="flex items-center gap-2 text-xs bg-slate-800 hover:bg-red-600 hover:text-white text-slate-300 px-3 py-2 rounded transition-colors font-bold uppercase tracking-wide"
                                 >
                                     <Undo size={14} /> Rollback Last Deploy
                                 </button>
                             </div>
                         </div>

                         {/* SELF-HEALING & AUTO-EVAL LOOP */}
                         <div className="bg-slate-900/30 border border-slate-800 rounded-xl p-6 border-t-4 border-t-emerald-500/50 relative overflow-hidden">
                             <div className="absolute top-0 right-0 p-4 opacity-10">
                                 <RefreshCw size={64} className="animate-spin-slow" />
                             </div>
                             <div className="flex items-center justify-between mb-6 relative z-10">
                                 <div>
                                     <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                         <Activity className="text-emerald-400" size={20} />
                                         SELF-HEALING & AUTO-EVAL LOOP
                                     </h3>
                                     <p className="text-slate-400 text-sm">Swarm continuously improves itself without human input.</p>
                                 </div>
                                 <button 
                                     onClick={toggleSelfHealing}
                                     className={`px-4 py-2 rounded-full font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg
                                         ${isSelfHealingOn ? 'bg-emerald-500 text-white shadow-emerald-500/20' : 'bg-slate-800 text-slate-500'}
                                     `}
                                 >
                                     <Power size={14} />
                                     {isSelfHealingOn ? 'Active: 24/7' : 'Loop Inactive'}
                                 </button>
                             </div>

                             <div className="overflow-x-auto relative z-10">
                                 <table className="w-full text-sm text-left text-slate-400">
                                     <thead className="text-xs text-slate-500 uppercase bg-slate-950/50 border-b border-slate-800">
                                         <tr>
                                             <th className="px-4 py-3">Capability</th>
                                             <th className="px-4 py-3">How It Works</th>
                                             <th className="px-4 py-3">Trigger Frequency</th>
                                         </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-800">
                                         {SELF_HEALING_CAPABILITIES.map(cap => (
                                             <tr key={cap.id} className="hover:bg-slate-900/50 transition-colors">
                                                 <td className="px-4 py-3 font-bold text-white flex items-center gap-2">
                                                     {cap.id === 'redteam' && <AlertTriangle size={12} className="text-red-400" />}
                                                     {cap.name}
                                                 </td>
                                                 <td className="px-4 py-3">{cap.mechanism}</td>
                                                 <td className="px-4 py-3 text-xs font-mono text-emerald-400">{cap.freq}</td>
                                             </tr>
                                         ))}
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                    </div>
                )}

                {activeTab === 'webhooks' && (
                     <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                         
                         {/* Specific Agent Triggers */}
                         <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
                             <div className="flex items-center justify-between mb-4">
                                 <div>
                                     <h3 className="text-lg font-bold text-white flex items-center gap-2">
                                         <Zap className="text-yellow-400" size={20} />
                                         {selectedOrisa} Triggers
                                     </h3>
                                     <p className="text-slate-400 text-sm">Configure external events that summon this Òrìṣà.</p>
                                 </div>
                             </div>
                             
                             <div className="space-y-3">
                                {currentConfig.webhookTriggers?.map((trigger, idx) => (
                                    <div key={idx} className="flex items-center gap-2 bg-slate-900 border border-slate-800 p-3 rounded-lg">
                                        <span className="text-xs font-bold bg-slate-800 text-slate-300 px-2 py-1 rounded uppercase">{trigger.event}</span>
                                        <span className="text-xs text-slate-500 font-mono flex-1 truncate">{trigger.endpoint}</span>
                                        <div className="flex items-center gap-2">
                                            <button 
                                                onClick={() => {
                                                    const newTriggers = [...(currentConfig.webhookTriggers || [])];
                                                    newTriggers[idx].enabled = !newTriggers[idx].enabled;
                                                    handleUpdate({ webhookTriggers: newTriggers });
                                                }}
                                                className={`${trigger.enabled ? 'text-green-400' : 'text-slate-600'}`}
                                            >
                                                <Power size={14} />
                                            </button>
                                            <button 
                                                onClick={() => {
                                                    const newTriggers = currentConfig.webhookTriggers?.filter((_, i) => i !== idx);
                                                    handleUpdate({ webhookTriggers: newTriggers });
                                                }}
                                                className="text-slate-600 hover:text-red-400"
                                            >
                                                <X size={14} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                                
                                {/* Add New Trigger */}
                                <div className="flex items-center gap-2 bg-slate-900/50 border border-slate-800/50 p-2 rounded-lg">
                                    <input 
                                        placeholder="Event Name (e.g. payment_received)"
                                        className="bg-transparent border-none text-xs text-slate-200 focus:ring-0 w-1/3"
                                        id="new-trigger-event"
                                    />
                                    <div className="w-px h-4 bg-slate-700"></div>
                                    <input 
                                        placeholder="Webhook Endpoint URL"
                                        className="bg-transparent border-none text-xs text-slate-200 focus:ring-0 flex-1 font-mono"
                                        id="new-trigger-endpoint"
                                    />
                                    <button 
                                        onClick={() => {
                                            const eventInput = document.getElementById('new-trigger-event') as HTMLInputElement;
                                            const endpointInput = document.getElementById('new-trigger-endpoint') as HTMLInputElement;
                                            if (eventInput.value && endpointInput.value) {
                                                handleUpdate({ 
                                                    webhookTriggers: [
                                                        ...(currentConfig.webhookTriggers || []), 
                                                        { event: eventInput.value, endpoint: endpointInput.value, enabled: true }
                                                    ] 
                                                });
                                                eventInput.value = '';
                                                endpointInput.value = '';
                                            }
                                        }}
                                        className="bg-slate-800 hover:bg-cyan-600 text-slate-400 hover:text-white p-1.5 rounded transition-colors"
                                    >
                                        <Plus size={14} />
                                    </button>
                                </div>
                             </div>
                         </section>

                         <div className="bg-gradient-to-r from-orange-900/20 to-slate-900 border border-orange-500/20 rounded-xl p-6">
                             <div className="flex items-start gap-4">
                                 <div className="p-3 bg-orange-500/10 rounded-lg border border-orange-500/20">
                                     <Globe className="text-orange-400" size={24} />
                                 </div>
                                 <div>
                                     <h3 className="text-xl font-bold text-white mb-1">Universal Webhook & API Panel</h3>
                                     <p className="text-slate-400 text-sm">Configure triggers for cross-tool flows. Use Gemini 3's native function calling for secure API orchestration.</p>
                                 </div>
                             </div>
                         </div>

                         <div className="grid grid-cols-1 gap-4">
                             {WEBHOOK_INTEGRATIONS.map(hook => (
                                 <div key={hook.id} className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex items-center justify-between group hover:border-orange-500/30 transition-colors">
                                     <div className="flex items-center gap-4">
                                         <div className="w-10 h-10 rounded-full bg-slate-950 flex items-center justify-center border border-slate-800 text-slate-500 font-bold text-xs">
                                             {hook.name.substring(0, 2).toUpperCase()}
                                         </div>
                                         <div>
                                             <h4 className="font-bold text-slate-200">{hook.name}</h4>
                                             <div className="text-xs text-slate-500">{hook.desc}</div>
                                         </div>
                                     </div>
                                     <div className="flex items-center gap-4">
                                          <div className="text-right hidden md:block">
                                              <div className="text-[10px] text-slate-500 font-mono uppercase">Setup</div>
                                              <div className="text-xs text-slate-400">{hook.setup}</div>
                                          </div>
                                          <button 
                                            onClick={() => {
                                                setSimInput(`Simulate webhook payload for ${hook.name} event.`);
                                            }}
                                            className="px-4 py-2 bg-slate-950 border border-slate-800 rounded hover:bg-orange-900/20 hover:text-orange-400 hover:border-orange-500/30 transition-all text-xs font-bold uppercase tracking-wider text-slate-400"
                                          >
                                              Test Hook
                                          </button>
                                     </div>
                                 </div>
                             ))}
                         </div>
                     </div>
                )}

                {activeTab === 'marketplace' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                         <div className="bg-gradient-to-r from-pink-900/20 to-slate-900 border border-pink-500/20 rounded-xl p-6">
                             <div className="flex items-start gap-4">
                                 <div className="p-3 bg-pink-500/10 rounded-lg border border-pink-500/20">
                                     <ShoppingBag className="text-pink-400" size={24} />
                                 </div>
                                 <div>
                                     <h3 className="text-xl font-bold text-white mb-1">Agent Marketplace & Economy</h3>
                                     <p className="text-slate-400 text-sm">Turn your agents into shareable, monetizable assets.</p>
                                 </div>
                             </div>
                             <div className="mt-6 flex gap-2">
                                 <button 
                                    onClick={simulatePublish}
                                    className="flex items-center gap-2 bg-pink-600 hover:bg-pink-500 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider shadow-lg shadow-pink-900/20 transition-all"
                                 >
                                     <ShoppingBag size={14} /> Publish to Marketplace
                                 </button>
                                 <button 
                                    onClick={simulateEarnMode}
                                    className="flex items-center gap-2 bg-slate-800 hover:bg-emerald-600 text-emerald-400 hover:text-white px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider border border-emerald-500/20 transition-all"
                                 >
                                     <Coins size={14} /> Earn Mode
                                 </button>
                             </div>
                         </div>

                         <div className="bg-slate-900/30 border border-slate-800 rounded-xl overflow-hidden">
                             <div className="overflow-x-auto">
                                 <table className="w-full text-sm text-left text-slate-400">
                                     <thead className="text-xs text-slate-500 uppercase bg-slate-950/50 border-b border-slate-800">
                                         <tr>
                                             <th className="px-4 py-3">Feature</th>
                                             <th className="px-4 py-3">Function</th>
                                             <th className="px-4 py-3">Implementation</th>
                                         </tr>
                                     </thead>
                                     <tbody className="divide-y divide-slate-800">
                                         {AGENT_MARKETPLACE.map(feat => (
                                             <tr key={feat.id} className="hover:bg-slate-900/50 transition-colors">
                                                 <td className="px-4 py-3 font-bold text-white">{feat.feature}</td>
                                                 <td className="px-4 py-3">{feat.func}</td>
                                                 <td className="px-4 py-3 font-mono text-xs">{feat.impl}</td>
                                             </tr>
                                         ))}
                                     </tbody>
                                 </table>
                             </div>
                         </div>
                    </div>
                )}

            </div>
         </div>
      </div>

      {/* Right Panel: Simulator */}
      {isSimulatorOpen && (
          <div className="w-96 bg-slate-950 border-l border-slate-800 flex flex-col z-20 shrink-0 transition-all duration-300 absolute md:static inset-y-0 right-0 shadow-2xl md:shadow-none">
            <div className="h-16 border-b border-slate-800 flex items-center justify-between px-4 bg-slate-950 shrink-0">
                <div className="flex items-center gap-2">
                    <Bot className="text-cyan-400" />
                    <div>
                        <h3 className="font-bold text-white text-sm">Antigravity Simulator</h3>
                        <div className="flex items-center gap-1 text-[10px] text-slate-500">
                            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
                            Gemini 3 Live
                        </div>
                    </div>
                </div>
                <button onClick={() => setIsSimulatorOpen(false)} className="text-slate-400 hover:text-white p-1">
                    <X size={16} />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950">
                {simMessages.length === 0 && (
                    <div className="text-center mt-10 opacity-50">
                        <Bot size={48} className="mx-auto mb-4 text-slate-700" />
                        <p className="text-sm text-slate-500">Spawning Agent Instance...</p>
                        <p className="text-xs text-slate-600 mt-2">Send a message to test {selectedOrisa}.</p>
                    </div>
                )}
                {simMessages.map(msg => (
                    <div key={msg.id} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className={`max-w-[90%] rounded-xl p-3 text-sm ${
                            msg.role === 'user' 
                                ? 'bg-cyan-600 text-white' 
                                : 'bg-slate-800 text-slate-300 border border-slate-700'
                        }`}>
                            {msg.content}
                        </div>
                        <span className="text-[10px] text-slate-600 mt-1 px-1">
                            {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                    </div>
                ))}
                {simEvents.map((evt, i) => (
                    <div key={i} className="flex justify-center">
                        {renderEvent(evt)}
                    </div>
                ))}
                {isSimulating && !simEvents.length && (
                    <div className="flex items-center gap-2 text-slate-500 text-xs pl-2">
                        <span className="animate-bounce">•</span>
                        <span className="animate-bounce delay-100">•</span>
                        <span className="animate-bounce delay-200">•</span>
                    </div>
                )}
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-2">
                <div className="flex justify-end">
                    <button 
                        onClick={simulateIncomingMessage}
                        disabled={isSimulating}
                        className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 hover:bg-slate-900 px-2 py-1 rounded transition-colors"
                    >
                        <ArrowRightLeft size={10} /> Simulate Peer Message
                    </button>
                </div>
                <div className="flex gap-2">
                    <input 
                        value={simInput}
                        onChange={(e) => setSimInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-4 py-2 text-sm text-white focus:ring-1 focus:ring-cyan-500 outline-none"
                        placeholder="Test your agent..."
                    />
                    <button 
                        onClick={handleSendMessage}
                        disabled={!simInput.trim() || isSimulating}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white p-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        <Send size={18} />
                    </button>
                </div>
            </div>
          </div>
      )}

      {/* Simulator Toggle (When Closed) */}
      {!isSimulatorOpen && (
          <button 
            onClick={() => setIsSimulatorOpen(true)}
            className="absolute bottom-6 right-6 bg-cyan-600 hover:bg-cyan-500 text-white p-3 rounded-full shadow-xl z-30 animate-in zoom-in duration-300"
          >
              <MessageSquare size={24} />
          </button>
      )}
    </div>
  );
};

function CheckCircleIcon({ className, size }: { className?: string, size?: number }) {
    return (
        <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width={size} 
            height={size} 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className={className}
        >
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
    )
}
