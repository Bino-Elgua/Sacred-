
import React from 'react';
import { Agent, AgentStatus } from '../types';
import { X, Terminal, FileText, Activity, BrainCircuit, CheckCircle2, AlertCircle, Bot, Cpu, RefreshCcw, Save, Sparkles, Code2, FileCode, AlertTriangle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface AgentDetailsModalProps {
  agent: Agent | null;
  onClose: () => void;
  onSave: (content: string, title?: string, tags?: string[], type?: 'report' | 'code' | 'log') => void;
}

export const AgentDetailsModal: React.FC<AgentDetailsModalProps> = ({ agent, onClose, onSave }) => {
  if (!agent) return null;

  const getStatusColor = (status: AgentStatus) => {
    switch (status) {
      case AgentStatus.IDLE: return 'text-gray-400 bg-gray-500/10 border-gray-500/20';
      case AgentStatus.THINKING: return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20';
      case AgentStatus.WORKING: return 'text-purple-400 bg-purple-500/10 border-purple-500/20';
      case AgentStatus.RECOVERING: return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case AgentStatus.WAITING: return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      case AgentStatus.COMPLETED: return 'text-green-400 bg-green-500/10 border-green-500/20';
      case AgentStatus.ERROR: return 'text-red-400 bg-red-500/10 border-red-500/20';
      default: return 'text-gray-400';
    }
  };

  const getIcon = () => {
      switch (agent.status) {
        case AgentStatus.THINKING: return <BrainCircuit size={20} />;
        case AgentStatus.WORKING: return <Cpu size={20} />;
        case AgentStatus.RECOVERING: return <RefreshCcw size={20} className="animate-spin" />;
        case AgentStatus.COMPLETED: return <CheckCircle2 size={20} />;
        case AgentStatus.ERROR: return <AlertCircle size={20} />;
        default: return <Bot size={20} />;
      }
  };

  const handleSave = () => {
      if (!agent.output) return;
      onSave(
          agent.output, 
          agent.filename || `${agent.orisa.name} Output`,
          ['agent-output', agent.role.toLowerCase().replace(' ', '-')],
          agent.filename ? 'code' : 'report'
      );
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-6 border-b border-slate-800 bg-slate-950">
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-xl border ${agent.orisa.colors}`}>
                        {getIcon()}
                    </div>
                    <div>
                        <div className="flex items-center gap-2">
                            <h2 className="text-xl font-bold text-white">{agent.orisa.name}</h2>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border ${getStatusColor(agent.status)}`}>
                                {agent.status}
                            </span>
                        </div>
                        <p className="text-slate-400 text-sm">{agent.role}</p>
                        <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                            <Sparkles size={10} /> {agent.orisa.domain}
                        </div>
                    </div>
                </div>
                <button 
                    onClick={onClose}
                    className="text-slate-400 hover:text-white p-2 hover:bg-slate-800 rounded-lg transition-colors"
                >
                    <X size={20} />
                </button>
            </div>

            {/* Technical Specs */}
            <div className="flex flex-wrap gap-4 mt-2">
                {agent.filename && (
                    <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded text-xs text-blue-300 flex items-center gap-2 font-mono">
                        <FileText size={12} />
                        {agent.filename}
                    </div>
                )}
                {agent.language && (
                    <div className="bg-slate-900 border border-slate-800 px-3 py-1.5 rounded text-xs text-purple-300 flex items-center gap-2 font-mono">
                        <Code2 size={12} />
                        {agent.language}
                    </div>
                )}
            </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-950/50">
            
            {/* Current Activity */}
            <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                    <Activity size={14} /> Current Activity
                </h3>
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg font-mono text-sm text-slate-300">
                    <span className="text-cyan-500 mr-2">{'>'}</span>
                    {agent.currentAction}
                </div>
            </div>

            {/* Error Display */}
            {agent.status === AgentStatus.ERROR && agent.errorMessage && (
                <div className="space-y-2">
                    <h3 className="text-xs font-bold text-red-500 uppercase tracking-wider flex items-center gap-2">
                        <AlertTriangle size={14} /> Error Details
                    </h3>
                    <div className="bg-red-950/20 border border-red-500/30 p-4 rounded-lg font-mono text-xs text-red-300 break-words">
                        {agent.errorMessage}
                    </div>
                </div>
            )}

            {/* Task Description */}
            <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                    <Terminal size={14} /> Mission Directive
                </h3>
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg text-sm text-slate-300 leading-relaxed">
                    {agent.taskDescription}
                </div>
            </div>

            {/* Output / Result */}
            {agent.output && (
                <div className="space-y-2">
                    <div className="flex items-center justify-between">
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-2">
                            <FileCode size={14} /> Generated Output
                        </h3>
                        <button 
                            onClick={handleSave}
                            className="text-xs flex items-center gap-1.5 bg-cyan-900/30 text-cyan-400 border border-cyan-500/30 px-3 py-1.5 rounded hover:bg-cyan-900/50 transition-colors"
                        >
                            <Save size={12} /> Save to Knowledge
                        </button>
                    </div>
                    <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
                        <div className="p-4 overflow-x-auto">
                            {agent.filename ? (
                                <pre className="font-mono text-xs text-slate-300">
                                    <code>{agent.output}</code>
                                </pre>
                            ) : (
                                <div className="prose prose-invert prose-sm max-w-none custom-markdown">
                                    <ReactMarkdown>{agent.output}</ReactMarkdown>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};
