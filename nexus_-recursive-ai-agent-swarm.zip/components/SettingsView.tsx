
import React, { useState } from 'react';
import { AppSettings, LLMProvider } from '../types';
import { Save, Key, Sliders, Shield, RefreshCcw, Brain, Network, Mic, Database, Globe } from 'lucide-react';

interface SettingsViewProps {
  settings: AppSettings;
  onSave: (newSettings: AppSettings) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ settings, onSave }) => {
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
  const [isDirty, setIsDirty] = useState(false);

  const handleChange = (section: keyof AppSettings, value: any) => {
    setLocalSettings(prev => ({ ...prev, [section]: value }));
    setIsDirty(true);
  };

  const handleLLMChange = (key: keyof AppSettings['llm'], value: any) => {
    setLocalSettings(prev => ({
      ...prev,
      llm: { ...prev.llm, [key]: value }
    }));
    setIsDirty(true);
  };

  const handleVoiceChange = (key: keyof AppSettings['voiceDefaults'], value: any) => {
    setLocalSettings(prev => ({
      ...prev,
      voiceDefaults: { ...prev.voiceDefaults, [key]: value }
    }));
    setIsDirty(true);
  };

  const saveSettings = () => {
    onSave(localSettings);
    setIsDirty(false);
  };

  return (
    <div className="h-full flex flex-col p-8 max-w-4xl mx-auto w-full overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
            <h2 className="text-2xl font-bold text-white mb-2">Global Settings</h2>
            <p className="text-slate-400">Configure intelligence providers, swarm limits, and system defaults.</p>
        </div>
        <button 
            onClick={saveSettings}
            disabled={!isDirty}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-lg font-medium transition-all
                ${isDirty 
                    ? 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-[0_0_20px_rgba(8,145,178,0.3)]' 
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'}
            `}
        >
            <Save size={18} />
            Save Changes
        </button>
      </div>

      <div className="space-y-6 pb-20">
        {/* LLM Configuration */}
        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-purple-500/10 rounded-lg border border-purple-500/20">
                    <Brain size={20} className="text-purple-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-200">Intelligence Provider</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Provider</label>
                    <select 
                        value={localSettings.llm.provider}
                        onChange={(e) => handleLLMChange('provider', e.target.value as LLMProvider)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-purple-500 outline-none text-slate-200"
                    >
                        <option value="gemini">Google Gemini (GenAI)</option>
                        <option value="openai">OpenAI (GPT-4)</option>
                        <option value="anthropic">Anthropic (Claude 3.5)</option>
                        <option value="custom">Custom / Local LLM</option>
                    </select>
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Model Name</label>
                    <input 
                        type="text"
                        value={localSettings.llm.model}
                        onChange={(e) => handleLLMChange('model', e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-purple-500 outline-none text-slate-200"
                        placeholder="e.g. gemini-1.5-pro"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-400 mb-2 flex items-center gap-2">
                        <Key size={14} /> API Key
                    </label>
                    <input 
                        type="password"
                        value={localSettings.llm.apiKey}
                        onChange={(e) => handleLLMChange('apiKey', e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-purple-500 outline-none text-slate-200 font-mono"
                        placeholder="sk-..."
                    />
                    <p className="text-xs text-slate-500 mt-2">Keys are stored in browser local storage only. Leave blank to use environment defaults.</p>
                </div>

                {/* Custom Endpoint Config */}
                {localSettings.llm.provider === 'custom' && (
                    <div className="md:col-span-2 space-y-4 p-4 bg-slate-950 rounded-lg border border-slate-800 animate-in fade-in slide-in-from-top-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-purple-400 uppercase tracking-wider mb-2">
                            <Globe size={14} /> Custom Endpoint Configuration
                        </div>
                        
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-2">Base URL / Endpoint</label>
                            <input 
                                type="text"
                                value={localSettings.llm.endpoint || ''}
                                onChange={(e) => handleLLMChange('endpoint', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-purple-500 outline-none text-slate-200 font-mono"
                                placeholder="https://api.openai.com/v1 or http://localhost:11434/v1"
                            />
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-2">Custom Headers (JSON)</label>
                            <textarea 
                                value={localSettings.llm.customHeaders || ''}
                                onChange={(e) => handleLLMChange('customHeaders', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-4 py-3 text-xs focus:ring-2 focus:ring-purple-500 outline-none text-slate-300 font-mono h-24"
                                placeholder='{"X-Custom-Auth": "value", "Organization": "my-org"}'
                            />
                        </div>
                    </div>
                )}
            </div>
        </section>

        {/* Swarm Orchestration & Limits */}
        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
             <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-blue-500/10 rounded-lg border border-blue-500/20">
                    <Network size={20} className="text-blue-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-200">Swarm Orchestration</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="flex justify-between text-sm font-medium text-slate-400 mb-2">
                        <span>Temperature (Global Creativity)</span>
                        <span className="text-blue-400">{localSettings.llm.temperature}</span>
                    </label>
                    <input 
                        type="range" 
                        min="0" 
                        max="1" 
                        step="0.1"
                        value={localSettings.llm.temperature}
                        onChange={(e) => handleLLMChange('temperature', parseFloat(e.target.value))}
                        className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                </div>
                
                <div>
                    <label className="flex justify-between text-sm font-medium text-slate-400 mb-2">
                        <span>Max Concurrent Agents</span>
                        <span className="text-blue-400">{localSettings.maxConcurrentAgents || 5}</span>
                    </label>
                    <input 
                        type="range" 
                        min="1" 
                        max="20" 
                        step="1"
                        value={localSettings.maxConcurrentAgents || 5}
                        onChange={(e) => handleChange('maxConcurrentAgents', parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                    />
                    <p className="text-xs text-slate-500 mt-2">Limit active workers to prevent API rate limits.</p>
                </div>
            </div>
        </section>

        {/* Memory & Context */}
        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
             <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/20">
                    <Database size={20} className="text-amber-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-200">Memory & Context</h3>
            </div>

            <div>
                 <label className="flex justify-between text-sm font-medium text-slate-400 mb-2">
                    <span>Context Window Size (Tokens)</span>
                    <span className="text-amber-400">{(localSettings.contextWindowSize || 128000).toLocaleString()}</span>
                </label>
                <input 
                    type="range" 
                    min="4096" 
                    max="1000000" 
                    step="4096"
                    value={localSettings.contextWindowSize || 128000}
                    onChange={(e) => handleChange('contextWindowSize', parseInt(e.target.value))}
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-xs text-slate-600 mt-1">
                    <span>4k (Fast)</span>
                    <span>1M (Deep)</span>
                </div>
            </div>
        </section>

        {/* Voice Defaults */}
        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
             <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-pink-500/10 rounded-lg border border-pink-500/20">
                    <Mic size={20} className="text-pink-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-200">Voice & Avatar Defaults</h3>
            </div>

            <div className="space-y-6">
                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-400 mb-2 flex items-center gap-2">
                        <Key size={14} /> ElevenLabs API Key
                    </label>
                    <input 
                        type="password"
                        value={localSettings.elevenLabsApiKey || ''}
                        onChange={(e) => handleChange('elevenLabsApiKey', e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-pink-500 outline-none text-slate-200 font-mono"
                        placeholder="xi-..."
                    />
                    <p className="text-xs text-slate-500 mt-2">Required for high-quality text-to-speech integration.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div>
                        <label className="block text-sm font-medium text-slate-400 mb-2">Default Voice ID</label>
                        <input 
                            type="text"
                            value={localSettings.voiceDefaults?.voiceId || ''}
                            onChange={(e) => handleVoiceChange('voiceId', e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-pink-500 outline-none text-slate-200"
                            placeholder="Global Voice ID (e.g. 21m00...)"
                        />
                     </div>
                     <div>
                         <label className="flex justify-between text-sm font-medium text-slate-400 mb-2">
                            <span>Base Stability</span>
                            <span className="text-pink-400">{localSettings.voiceDefaults?.stability || 0.5}</span>
                         </label>
                         <input 
                            type="range" min="0" max="1" step="0.1"
                            value={localSettings.voiceDefaults?.stability || 0.5}
                            onChange={(e) => handleVoiceChange('stability', parseFloat(e.target.value))}
                            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
                         />
                     </div>
                </div>
            </div>
        </section>

        {/* System */}
        <section className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                    <Shield size={20} className="text-emerald-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-200">System Preferences</h3>
            </div>

            <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
                    <div>
                        <h4 className="text-sm font-medium text-slate-200">Debug Mode</h4>
                        <p className="text-xs text-slate-500">Show extended logs and reasoning steps in console.</p>
                    </div>
                    <button 
                        onClick={() => handleChange('debugMode', !localSettings.debugMode)}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                            ${localSettings.debugMode ? 'bg-emerald-500' : 'bg-slate-700'}
                        `}
                    >
                        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition duration-200 ease-in-out
                            ${localSettings.debugMode ? 'translate-x-6' : 'translate-x-1'}
                        `}/>
                    </button>
                </div>

                <div className="flex items-center justify-between p-4 bg-slate-950 rounded-lg border border-slate-800">
                    <div>
                        <h4 className="text-sm font-medium text-slate-200">Auto-Save Work</h4>
                        <p className="text-xs text-slate-500">Automatically save successful mission reports to Knowledge Base.</p>
                    </div>
                    <button 
                         onClick={() => handleChange('autoSave', !localSettings.autoSave)}
                         className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                            ${localSettings.autoSave ? 'bg-emerald-500' : 'bg-slate-700'}
                        `}
                    >
                        <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition duration-200 ease-in-out
                            ${localSettings.autoSave ? 'translate-x-6' : 'translate-x-1'}
                        `}/>
                    </button>
                </div>
            </div>
        </section>
      </div>
    </div>
  );
};
