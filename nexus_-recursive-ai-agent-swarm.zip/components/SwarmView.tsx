
import React, { useEffect, useRef, useState } from 'react';
import { Agent, AgentStatus, AgentMessage, LLMConfig } from '../types';
import { AgentNode } from './AgentNode';
import { DataStream } from './DataStream';
import { AgentDetailsModal } from './AgentDetailsModal';
import { Sparkles, Play, RotateCcw, Bug, Save, MessageSquare, ChevronDown, ChevronUp, Wand2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { optimizePrompt } from '../services/geminiService';

interface SwarmViewProps {
  goal: string;
  setGoal: (g: string) => void;
  customRolesInput: string;
  setCustomRolesInput: (r: string) => void;
  agents: Agent[];
  isProcessing: boolean;
  isDebugMode: boolean;
  setIsDebugMode: (v: boolean) => void;
  finalResult: string | null;
  handleStart: () => void;
  reset: () => void;
  selectedAgentId: string | null;
  setSelectedAgentId: (id: string | null) => void;
  onSaveToKnowledge: (content: string, title?: string, tags?: string[], type?: 'report' | 'code' | 'log') => void;
  messages?: AgentMessage[];
  llmConfig?: LLMConfig;
}

// --- Message Layer Component ---
const MessageLayer: React.FC<{ messages: AgentMessage[]; agents: Agent[] }> = ({ messages, agents }) => {
    const svgRef = useRef<SVGSVGElement>(null);
    const [paths, setPaths] = useState<{ id: string; d: string; color: string }[]>([]);

    useEffect(() => {
        const updatePaths = () => {
            if (!svgRef.current) return;
            
            const newPaths = messages.map(msg => {
                const fromEl = document.getElementById(`agent-node-${msg.fromAgentId}`);
                const toEl = document.getElementById(`agent-node-${msg.toAgentId}`);
                
                if (!fromEl || !toEl) return null;
                
                const parentRect = svgRef.current!.getBoundingClientRect();
                const fromRect = fromEl.getBoundingClientRect();
                const toRect = toEl.getBoundingClientRect();

                const x1 = fromRect.left + fromRect.width / 2 - parentRect.left;
                const y1 = fromRect.top + fromRect.height / 2 - parentRect.top;
                const x2 = toRect.left + toRect.width / 2 - parentRect.left;
                const y2 = toRect.top + toRect.height / 2 - parentRect.top;

                // Calculate control points for a nice curve
                const cx1 = x1 + (x2 - x1) / 2;
                const cy1 = y1 - 80; // Deeper curve up to avoid overlapping nodes
                const cx2 = x2 - (x2 - x1) / 2;
                const cy2 = y2 - 80;

                return {
                    id: msg.id,
                    d: `M ${x1} ${y1} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${x2} ${y2}`,
                    color: msg.type === 'query' ? '#facc15' : msg.type === 'directive' ? '#ef4444' : '#3b82f6'
                };
            }).filter(Boolean) as { id: string; d: string; color: string }[];
            
            setPaths(newPaths);
        };

        // Poll for position changes during animations
        const interval = setInterval(updatePaths, 100);
        window.addEventListener('resize', updatePaths);
        
        // Initial check
        setTimeout(updatePaths, 500);
        
        return () => {
            clearInterval(interval);
            window.removeEventListener('resize', updatePaths);
        }
    }, [messages, agents]);

    return (
        <svg ref={svgRef} className="absolute inset-0 w-full h-full pointer-events-none overflow-visible z-20">
            <defs>
                <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#fff" opacity="0.7" />
                </marker>
            </defs>
            {paths.map(p => (
                <g key={p.id}>
                    {/* Static Path */}
                    <path 
                        d={p.d} 
                        stroke={p.color} 
                        strokeWidth="1" 
                        fill="none" 
                        opacity="0.4" 
                        strokeDasharray="4 4" 
                        markerEnd="url(#arrowhead)"
                    />
                    {/* Moving Packet */}
                    <circle r="4" fill={p.color} filter="drop-shadow(0 0 4px rgba(255,255,255,0.5))">
                        <animateMotion dur="2s" repeatCount="indefinite" path={p.d} keyPoints="0;1" keyTimes="0;1" />
                    </circle>
                </g>
            ))}
        </svg>
    );
};

// --- Cosmic Dust Background ---
const CosmicBackground: React.FC = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let particles: { x: number, y: number, vx: number, vy: number, size: number, alpha: number }[] = [];
        const particleCount = 80;

        const resize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        window.addEventListener('resize', resize);
        resize();

        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.2,
                vy: (Math.random() - 0.5) * 0.2,
                size: Math.random() * 2,
                alpha: Math.random() * 0.5 + 0.1
            });
        }

        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;

                if (p.x < 0) p.x = canvas.width;
                if (p.x > canvas.width) p.x = 0;
                if (p.y < 0) p.y = canvas.height;
                if (p.y > canvas.height) p.y = 0;

                ctx.fillStyle = `rgba(100, 200, 255, ${p.alpha})`;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });

            requestAnimationFrame(animate);
        };
        animate();

        return () => window.removeEventListener('resize', resize);
    }, []);

    return <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0 opacity-30" />;
};


export const SwarmView: React.FC<SwarmViewProps> = ({
  goal, setGoal,
  customRolesInput, setCustomRolesInput,
  agents, isProcessing,
  isDebugMode, setIsDebugMode,
  finalResult, handleStart, reset,
  selectedAgentId, setSelectedAgentId,
  onSaveToKnowledge,
  messages = [],
  llmConfig
}) => {
  const esuAgent = agents.find(a => a.id === 'esu');
  const obatalaAgent = agents.find(a => a.id === 'obatala');
  const pantheonAgents = agents.filter(a => a.id !== 'esu' && a.id !== 'obatala');
  const selectedAgent = agents.find(a => a.id === selectedAgentId) || null;
  const [isInputExpanded, setIsInputExpanded] = useState(false);
  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleOptimize = async () => {
      if (!goal.trim() || isOptimizing) return;
      setIsOptimizing(true);
      try {
          const optimized = await optimizePrompt(goal, llmConfig);
          setGoal(optimized);
      } finally {
          setIsOptimizing(false);
      }
  };

  return (
    <div className="h-full w-full flex flex-col overflow-hidden relative bg-slate-950">
        
        {/* Collapsible Control Bar (Floating Overlay) */}
        <div className="absolute top-6 left-1/2 -translate-x-1/2 z-30 w-full max-w-3xl flex justify-center transition-all duration-300">
            
            {!isInputExpanded ? (
                /* Collapsed State: Launch Button */
                <button 
                    onClick={() => setIsInputExpanded(true)}
                    className="bg-slate-900/90 backdrop-blur border border-slate-700/50 text-slate-300 px-6 py-3 rounded-full shadow-2xl flex items-center gap-3 hover:bg-slate-800 hover:text-white hover:border-cyan-500/50 transition-all group animate-in fade-in slide-in-from-top-4"
                >
                    <MessageSquare size={18} className="text-cyan-400 group-hover:scale-110 transition-transform" />
                    <span className="text-sm font-medium">Initialize Protocol</span>
                    <div className="w-px h-4 bg-slate-700 mx-1" />
                    <ChevronDown size={16} className="opacity-50" />
                </button>
            ) : (
                /* Expanded State: Full Input Interface */
                <div className="w-[90%] md:w-full bg-slate-900/95 backdrop-blur-xl border border-slate-800 rounded-2xl p-3 shadow-2xl flex flex-col gap-2 animate-in zoom-in-95 duration-200 ring-1 ring-cyan-500/20">
                     <div className="flex flex-col md:flex-row gap-2">
                         <div className="flex-1 relative group">
                            <MessageSquare className="absolute left-3 top-1/2 -translate-x-0 -translate-y-1/2 text-slate-500" size={16} />
                            <textarea
                                value={goal}
                                onChange={(e) => setGoal(e.target.value)}
                                disabled={isProcessing}
                                placeholder="Describe your AAA+ Enterprise objective..."
                                className="w-full bg-slate-950/50 border border-slate-700/50 rounded-lg pl-10 pr-12 py-3 text-sm focus:ring-2 focus:ring-cyan-500/50 outline-none text-white placeholder-slate-500 transition-all focus:bg-slate-950 resize-none min-h-[50px]"
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter' && !e.shiftKey && !isProcessing) {
                                        e.preventDefault();
                                        handleStart();
                                    }
                                }}
                                autoFocus
                            />
                            {/* Magic Wand for Optimization */}
                            <button 
                                onClick={handleOptimize}
                                disabled={isOptimizing || !goal.trim()}
                                className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md text-slate-500 hover:text-purple-400 hover:bg-purple-900/20 transition-all"
                                title="Auto-Enhance Goal with Gemini"
                            >
                                {isOptimizing ? <span className="animate-spin">⟳</span> : <Wand2 size={16} />}
                            </button>
                         </div>
                         
                         <div className="flex gap-2 justify-end items-start">
                            <button
                                onClick={() => setIsDebugMode(!isDebugMode)}
                                className={`p-2.5 rounded-lg border transition-all flex items-center justify-center ${
                                    isDebugMode 
                                    ? 'bg-amber-500/10 border-amber-500/50 text-amber-400' 
                                    : 'bg-slate-800/50 border-transparent text-slate-500 hover:text-slate-300'
                                }`}
                                title="Debug Mode"
                            >
                                <Bug size={18} />
                            </button>

                            {finalResult && (
                                <button 
                                    onClick={reset}
                                    className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-4 py-2 rounded-lg transition-colors border border-slate-700 flex items-center justify-center gap-2 text-sm h-full"
                                >
                                    <RotateCcw size={16} /> Reset
                                </button>
                            )}
                            
                            <button
                                onClick={handleStart}
                                disabled={isProcessing || !goal.trim()}
                                className="bg-red-600 hover:bg-red-500 text-white px-6 py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-red-900/20 min-w-[100px] h-full"
                            >
                                {isProcessing ? <span className="animate-spin">⟳</span> : <Play size={16} />}
                                {isProcessing ? 'Running' : 'Execute'}
                            </button>

                            <button 
                                onClick={() => setIsInputExpanded(false)}
                                className="p-2 text-slate-500 hover:text-white hover:bg-slate-800 rounded-lg transition-colors h-full"
                                title="Collapse"
                            >
                                <ChevronUp size={20} />
                            </button>
                         </div>
                     </div>
                </div>
            )}
        </div>

        {/* Visualization Area */}
        <div className="flex-1 relative overflow-hidden flex flex-col items-center justify-center bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-black">
             {/* Background Grid */}
             <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808008_1px,transparent_1px),linear-gradient(to_bottom,#80808008_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>
             
             {/* Cosmic Particles */}
             <CosmicBackground />

             {/* Message Visualization Layer */}
             {messages.length > 0 && <MessageLayer messages={messages} agents={agents} />}

             <div className="relative w-full h-full p-8 overflow-auto flex flex-col items-center min-h-[600px]">
                {/* Esu Node (Top) */}
                {esuAgent && (
                    <div className="z-10 mb-16 relative mt-24">
                        <AgentNode 
                            agent={esuAgent} 
                            onClick={() => setSelectedAgentId(esuAgent.id)}
                            isSelected={selectedAgentId === esuAgent.id}
                        />
                        {pantheonAgents.length > 0 && (
                        <DataStream type="manager" status={esuAgent.status} />
                        )}
                    </div>
                )}

                {/* Pantheon Grid */}
                {pantheonAgents.length > 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-x-16 gap-y-12 z-10 w-full max-w-7xl place-items-center animate-in fade-in zoom-in-95 duration-500 mb-16">
                        {pantheonAgents.map((worker) => (
                            <div key={worker.id} className="relative">
                                <DataStream type="worker" status={worker.status} />
                                <AgentNode 
                                    agent={worker} 
                                    onClick={() => setSelectedAgentId(worker.id)}
                                    isSelected={selectedAgentId === worker.id}
                                />
                            </div>
                        ))}
                    </div>
                )}
                
                {/* Obatala Node (Bottom) */}
                {obatalaAgent && pantheonAgents.length > 0 && (
                    <div className="z-10 mt-auto mb-10 relative animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-500">
                        <AgentNode 
                            agent={obatalaAgent} 
                            onClick={() => setSelectedAgentId(obatalaAgent.id)}
                            isSelected={selectedAgentId === obatalaAgent.id}
                        />
                    </div>
                )}

                {agents.length === 1 && !isProcessing && !finalResult && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-700 pointer-events-none">
                        <Sparkles size={64} className="mb-4 opacity-20" />
                        <p className="text-lg font-light opacity-50">Awaiting Enterprise Objective</p>
                    </div>
                )}
             </div>
        </div>

        <AgentDetailsModal 
            agent={selectedAgent} 
            onClose={() => setSelectedAgentId(null)} 
            onSave={onSaveToKnowledge}
        />
    </div>
  );
};
