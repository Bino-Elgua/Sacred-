
import React from 'react';
import { LayoutDashboard, Database, Settings, Network, Activity, X, TerminalSquare, Hammer, Volume2, VolumeX } from 'lucide-react';
import { View } from '../types';
import { speechService } from '../services/speechService';

interface SidebarProps {
  currentView: View;
  onViewChange: (view: View) => void;
  isProcessing: boolean;
  isOpen: boolean;
  onClose: () => void;
  narratorEnabled?: boolean;
  onToggleNarrator?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onViewChange, isProcessing, isOpen, onClose, narratorEnabled = true, onToggleNarrator }) => {
  const navItems: { id: View; label: string; icon: React.ReactNode }[] = [
    { id: 'swarm', label: 'Command Center', icon: <LayoutDashboard size={20} /> },
    { id: 'forge', label: 'Pantheon Forge', icon: <Hammer size={20} /> },
    { id: 'knowledge', label: 'Knowledge Base', icon: <Database size={20} /> },
    // Tools item removed
    { id: 'logs', label: 'System Logs', icon: <TerminalSquare size={20} /> },
    { id: 'settings', label: 'Global Settings', icon: <Settings size={20} /> },
  ];

  const handleNarratorToggle = () => {
      if (onToggleNarrator) {
          onToggleNarrator();
          speechService.setEnabled(!narratorEnabled);
      }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <div className={`
        fixed md:static inset-y-0 left-0 w-64 bg-slate-950 border-r border-slate-800 
        flex flex-col z-50 transition-transform duration-300 ease-in-out shadow-2xl md:shadow-none
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        {/* Logo Area */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
              <Network className="text-cyan-400" size={24} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight">Nexus</h1>
              <p className="text-[10px] text-slate-500 font-mono">ENTERPRISE</p>
            </div>
          </div>
          {/* Mobile Close Button */}
          <button onClick={onClose} className="md:hidden text-slate-400 hover:text-white">
            <X size={20} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                onViewChange(item.id);
                onClose(); // Close sidebar on mobile on selection
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 text-sm font-medium
                ${currentView === item.id 
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_15px_rgba(6,182,212,0.1)]' 
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }
              `}
            >
              {item.icon}
              {item.label}
              {item.id === 'swarm' && isProcessing && (
                <div className="ml-auto relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
                </div>
              )}
            </button>
          ))}
        </nav>

        {/* Footer Tools */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/30 space-y-4">
          {/* Narrator Toggle */}
          <button 
            onClick={handleNarratorToggle}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 transition-colors group"
          >
              <div className="flex items-center gap-2">
                  {narratorEnabled ? <Volume2 size={16} className="text-cyan-400" /> : <VolumeX size={16} className="text-slate-500" />}
                  <span className={`text-xs font-medium ${narratorEnabled ? 'text-cyan-100' : 'text-slate-500'}`}>
                      Èṣù's Voice
                  </span>
              </div>
              <div className={`w-2 h-2 rounded-full ${narratorEnabled ? 'bg-cyan-500 animate-pulse' : 'bg-slate-600'}`} />
          </button>

          {/* System Status */}
          <div>
            <div className="flex items-center gap-2 mb-2">
                <Activity size={14} className="text-emerald-400" />
                <span className="text-xs font-bold text-slate-300">System Online</span>
            </div>
            <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                <div className="bg-emerald-500 h-full w-[98%] shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
            </div>
            <div className="mt-2 flex justify-between text-[10px] text-slate-500 font-mono">
                <span>CPU: 12%</span>
                <span>MEM: 4GB</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
