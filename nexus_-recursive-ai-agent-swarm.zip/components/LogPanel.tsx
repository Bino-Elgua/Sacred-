
import React, { useEffect, useRef } from 'react';
import { LogMessage } from '../types';
import { Terminal, Clock, Activity, Bug, AlertTriangle } from 'lucide-react';

interface LogPanelProps {
  logs: LogMessage[];
}

export const LogPanel: React.FC<LogPanelProps> = ({ logs }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getTypeColor = (type: LogMessage['type']) => {
    switch (type) {
      case 'info': return 'text-blue-400';
      case 'success': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'system': return 'text-purple-400';
      case 'debug': return 'text-amber-500/70';
      case 'warning': return 'text-amber-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg flex flex-col h-full shadow-xl overflow-hidden">
      <div className="bg-gray-950 px-4 py-2 border-b border-gray-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal size={16} className="text-gray-400" />
          <span className="text-xs font-mono font-bold text-gray-300 uppercase tracking-wider">System Logs</span>
        </div>
        <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
             <span className="text-[10px] text-gray-500 font-mono">LIVE</span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-3 scrollbar-hide">
        {logs.length === 0 && (
            <div className="text-gray-600 text-center mt-10 italic">Waiting for input sequence...</div>
        )}
        {logs.map((log) => (
          <div key={log.id} className="flex gap-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="text-gray-600 shrink-0 w-16">
              {new Date(log.timestamp).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </div>
            <div className="flex-1 break-words">
              <span className={`font-bold ${getTypeColor(log.type)} mr-2 inline-flex items-center gap-1`}>
                {log.type === 'debug' && <Bug size={10} />}
                {log.type === 'warning' && <AlertTriangle size={10} />}
                [{log.agentRole}]
              </span>
              <span className={log.type === 'debug' ? 'text-gray-500 font-mono' : 'text-gray-300'}>
                  {log.message}
              </span>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  );
};