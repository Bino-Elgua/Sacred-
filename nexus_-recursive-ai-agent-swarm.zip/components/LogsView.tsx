
import React, { useState, useMemo } from 'react';
import { LogPanel } from './LogPanel';
import { LogMessage, ProjectArtifact } from '../types';
import { Trash2, Download, Filter, Folder, File, Code, ChevronRight, ChevronDown, Terminal } from 'lucide-react';

interface LogsViewProps {
  logs: LogMessage[];
  onClearLogs: () => void;
  artifacts?: ProjectArtifact[];
}

export const LogsView: React.FC<LogsViewProps> = ({ logs, onClearLogs, artifacts = [] }) => {
  const [activeTab, setActiveTab] = useState<'logs' | 'artifacts'>('logs');
  const [selectedArtifact, setSelectedArtifact] = useState<ProjectArtifact | null>(null);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());
  
  // Filters
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedRole, setSelectedRole] = useState<string>('all');

  // Compute unique roles
  const roles = useMemo(() => {
      const unique = new Set(logs.map(l => l.agentRole));
      return Array.from(unique).sort();
  }, [logs]);

  // Filtered Logs
  const filteredLogs = useMemo(() => {
      return logs.filter(log => {
          const typeMatch = selectedType === 'all' || log.type === selectedType;
          const roleMatch = selectedRole === 'all' || log.agentRole === selectedRole;
          return typeMatch && roleMatch;
      });
  }, [logs, selectedType, selectedRole]);

  const downloadLogs = () => {
    const text = filteredLogs.map(l => `[${new Date(l.timestamp).toISOString()}] [${l.type.toUpperCase()}] [${l.agentRole}]: ${l.message}`).join('\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nexus-logs-${Date.now()}.log`;
    a.click();
  };

  const downloadProject = () => {
      if (artifacts.length === 0) return;
      const jsonStr = JSON.stringify(artifacts, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `pantheon-project-${Date.now()}.json`;
      a.click();
  };

  const toggleFolder = (path: string) => {
      const newSet = new Set(expandedFolders);
      if (newSet.has(path)) newSet.delete(path);
      else newSet.add(path);
      setExpandedFolders(newSet);
  };

  const renderTree = (nodes: ProjectArtifact[], parentPath: string = '') => {
      return (
          <div className="pl-4 border-l border-slate-800/50">
              {nodes.map((node, idx) => {
                  const path = `${parentPath}/${node.name}`;
                  const isExpanded = expandedFolders.has(path);
                  const isSelected = selectedArtifact === node;

                  if (node.type === 'folder') {
                      return (
                          <div key={path}>
                              <div 
                                  onClick={() => toggleFolder(path)}
                                  className="flex items-center gap-2 py-1 cursor-pointer hover:text-white text-slate-400 select-none"
                              >
                                  {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                                  <Folder size={14} className="text-blue-400" />
                                  <span className="text-sm font-mono">{node.name}</span>
                              </div>
                              {isExpanded && node.children && renderTree(node.children, path)}
                          </div>
                      );
                  } else {
                      return (
                          <div 
                              key={path}
                              onClick={() => setSelectedArtifact(node)}
                              className={`flex items-center gap-2 py-1 cursor-pointer select-none pl-5 transition-colors
                                  ${isSelected ? 'text-cyan-400 bg-cyan-950/30 rounded' : 'text-slate-500 hover:text-slate-300'}
                              `}
                          >
                              <File size={14} className={isSelected ? 'text-cyan-400' : 'text-slate-600'} />
                              <span className="text-sm font-mono">{node.name}</span>
                          </div>
                      );
                  }
              })}
          </div>
      );
  };

  return (
    <div className="h-full flex flex-col p-4 md:p-6 bg-slate-950">
      <div className="flex items-center justify-between mb-6">
        <div>
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                System Monitor
            </h2>
            <p className="text-slate-400 text-sm">Real-time logs and generated project artifacts.</p>
        </div>
        
        <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button 
                onClick={() => setActiveTab('logs')}
                className={`px-4 py-1.5 rounded text-sm font-medium transition-all flex items-center gap-2
                    ${activeTab === 'logs' ? 'bg-slate-800 text-white shadow' : 'text-slate-400 hover:text-slate-200'}
                `}
            >
                <Terminal size={14} /> Logs
            </button>
            <button 
                onClick={() => setActiveTab('artifacts')}
                className={`px-4 py-1.5 rounded text-sm font-medium transition-all flex items-center gap-2
                    ${activeTab === 'artifacts' ? 'bg-slate-800 text-white shadow' : 'text-slate-400 hover:text-slate-200'}
                `}
            >
                <Code size={14} /> Artifacts
            </button>
        </div>
      </div>

      {activeTab === 'logs' ? (
          <div className="flex-1 flex flex-col overflow-hidden">
                <div className="flex justify-between items-center mb-2 gap-2 flex-wrap">
                    {/* Filters */}
                    <div className="flex items-center gap-2">
                        <div className="relative">
                            <Filter size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500" />
                            <select 
                                value={selectedType}
                                onChange={(e) => setSelectedType(e.target.value)}
                                className="bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded pl-8 pr-4 py-1.5 outline-none focus:border-cyan-500"
                            >
                                <option value="all">All Types</option>
                                <option value="info">Info</option>
                                <option value="success">Success</option>
                                <option value="error">Error</option>
                                <option value="warning">Warning</option>
                                <option value="debug">Debug</option>
                                <option value="system">System</option>
                            </select>
                        </div>
                        <select 
                            value={selectedRole}
                            onChange={(e) => setSelectedRole(e.target.value)}
                            className="bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded px-4 py-1.5 outline-none focus:border-cyan-500 max-w-[150px]"
                        >
                            <option value="all">All Roles</option>
                            {roles.map(r => <option key={r} value={r}>{r}</option>)}
                        </select>
                        <span className="text-xs text-slate-500 ml-2">{filteredLogs.length} events</span>
                    </div>

                    <div className="flex gap-2">
                        <button 
                            onClick={downloadLogs}
                            className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-800 transition-colors text-xs"
                        >
                            <Download size={14} /> Export
                        </button>
                        <button 
                            onClick={onClearLogs}
                            className="flex items-center gap-2 px-3 py-1.5 bg-slate-900 hover:bg-red-950/30 text-slate-300 hover:text-red-400 rounded border border-slate-800 transition-colors text-xs"
                        >
                            <Trash2 size={14} /> Clear
                        </button>
                    </div>
                </div>
                <div className="flex-1 overflow-hidden border border-slate-800 rounded-xl shadow-2xl">
                    <LogPanel logs={filteredLogs} />
                </div>
          </div>
      ) : (
          <div className="flex-1 flex overflow-hidden gap-4 border border-slate-800 rounded-xl bg-slate-900/30 p-4">
              {/* File Tree */}
              <div className="w-1/3 flex flex-col border-r border-slate-800 pr-4">
                   <div className="flex items-center justify-between mb-4">
                       <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">File Structure</h3>
                       <button 
                           onClick={downloadProject}
                           className="p-1.5 hover:bg-slate-800 rounded text-cyan-400 transition-colors" 
                           title="Download Project JSON"
                       >
                           <Download size={16} />
                       </button>
                   </div>
                   <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800">
                       {artifacts.length > 0 ? renderTree(artifacts) : (
                           <div className="text-slate-600 text-sm italic text-center mt-10">
                               No artifacts generated yet.<br/>Execute a mission first.
                           </div>
                       )}
                   </div>
              </div>

              {/* Code Viewer */}
              <div className="flex-1 flex flex-col overflow-hidden bg-slate-950 rounded-lg border border-slate-800">
                   {selectedArtifact && selectedArtifact.type === 'file' ? (
                       <>
                           <div className="px-4 py-2 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between">
                               <span className="text-sm font-mono text-cyan-400">{selectedArtifact.name}</span>
                               <span className="text-xs text-slate-500 uppercase">{selectedArtifact.language || 'TEXT'}</span>
                           </div>
                           <div className="flex-1 overflow-auto p-4">
                               <pre className="font-mono text-xs text-slate-300 leading-relaxed">
                                   <code>{selectedArtifact.content}</code>
                               </pre>
                           </div>
                       </>
                   ) : (
                       <div className="flex items-center justify-center h-full text-slate-600">
                           <div className="text-center">
                               <Code size={32} className="mx-auto mb-2 opacity-50" />
                               <p className="text-sm">Select a file to view contents</p>
                           </div>
                       </div>
                   )}
              </div>
          </div>
      )}
    </div>
  );
};
