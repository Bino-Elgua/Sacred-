
import React from 'react';
import { AgentStatus } from '../types';

interface DataStreamProps {
  type: 'manager' | 'worker';
  status: AgentStatus;
}

export const DataStream: React.FC<DataStreamProps> = ({ type, status }) => {
  const isManager = type === 'manager';
  
  // Visual configuration based on state
  let isActive = false;
  let direction: 'down' | 'up' = 'down';
  let colorFrom = isManager ? 'from-red-500' : 'from-purple-500';
  let glowColor = isManager ? 'shadow-red-400' : 'shadow-purple-400';

  if (isManager) {
    // Manager flows down when summoning
    if (status === AgentStatus.WAITING || status === AgentStatus.WORKING || status === AgentStatus.THINKING) {
      isActive = true;
      direction = 'down';
      colorFrom = 'from-red-500';
    }
  } else {
    // Worker Logic
    if (status === AgentStatus.WORKING) {
      isActive = true;
      direction = 'down'; // Receiving Task Data
      colorFrom = 'from-white'; // Divine Inspiration
      glowColor = 'shadow-white';
    } else if (status === AgentStatus.COMPLETED) {
      isActive = true;
      direction = 'up'; // Sending Results
      colorFrom = 'from-emerald-400';
      glowColor = 'shadow-emerald-400';
    }
  }

  // CSS positioning for the line relative to the AgentNode
  const positionClasses = isManager 
    ? 'top-full h-12' 
    : 'bottom-full h-8 -translate-y-2';

  const gradientDir = isManager ? 'bg-gradient-to-b' : 'bg-gradient-to-t';
  
  // Base line opacity and color
  const baseGradient = isActive 
    ? `${gradientDir} ${colorFrom} to-transparent`
    : `${gradientDir} ${isManager ? 'from-red-900/20' : 'from-slate-800/20'} to-transparent`;

  return (
    <div className={`absolute left-1/2 w-px -translate-x-1/2 ${positionClasses} overflow-visible pointer-events-none z-0`}>
      
      {/* Static Base Line */}
      <div className={`w-full h-full ${baseGradient} transition-all duration-500`} />

      {/* Moving Data Packet (The "Message") */}
      {isActive && (
        <div className={`absolute left-1/2 -translate-x-1/2 w-1.5 h-3 bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.8)] blur-[0.5px] z-10
          ${direction === 'down' ? 'animate-packet-down' : 'animate-packet-up'}
          ${glowColor}
        `} />
      )}

      {/* Flowing Data Stream Effect */}
      {isActive && (
         <div className={`absolute inset-0 w-full h-full opacity-60
           bg-[linear-gradient(to_bottom,transparent_40%,#fff_50%,transparent_60%)] 
           bg-[size:100%_16px]
           ${direction === 'down' ? 'animate-flow-y' : 'animate-flow-y-reverse'}
         `} />
      )}
    </div>
  );
};
