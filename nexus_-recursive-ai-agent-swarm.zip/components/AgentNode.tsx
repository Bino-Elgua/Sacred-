
import React, { useState } from 'react';
import { Agent, AgentStatus } from '../types';
import { Bot, Cpu, CheckCircle2, AlertCircle, BrainCircuit, MousePointerClick, RefreshCcw, Sparkles } from 'lucide-react';

interface AgentNodeProps {
  agent: Agent;
  onClick?: () => void;
  isSelected?: boolean;
}

export const AgentNode: React.FC<AgentNodeProps> = ({ agent, onClick, isSelected }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  const getStatusIcon = () => {
    switch (agent.status) {
      case AgentStatus.IDLE: return <Bot className="opacity-50" />;
      case AgentStatus.THINKING: return <BrainCircuit className="animate-pulse" />;
      case AgentStatus.WORKING: return <Cpu className="animate-[spin_3s_linear_infinite]" />;
      case AgentStatus.RECOVERING: return <RefreshCcw className="animate-[spin_2s_linear_infinite]" />;
      case AgentStatus.COMPLETED: return <CheckCircle2 />;
      case AgentStatus.ERROR: return <AlertCircle />;
      default: return <Bot />;
    }
  };

  // Use the Orisa specific colors or fallbacks
  // Expecting Tailwind classes in `agent.orisa.colors` like "border-red-500 bg-red-900 text-red-400"
  const colors = agent.orisa?.colors || "border-slate-700 bg-slate-800 text-slate-400";

  const getNodeStyles = () => {
    const base = "relative flex flex-col w-72 rounded-xl p-4 transition-all duration-500 cursor-pointer hover:-translate-y-1 backdrop-blur-md border";
    
    if (isSelected) {
        return `${base} ${colors.replace('/30', '/90').replace('/50', '')} shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)] scale-105 z-20 ring-1 ring-white/20`;
    }
    
    // Active states get a stronger glow
    if (agent.status === AgentStatus.WORKING || agent.status === AgentStatus.THINKING) {
        return `${base} ${colors} shadow-[0_0_25px_-5px_rgba(255,255,255,0.15)]`;
    }
    
    return `${base} ${colors}`;
  };

  return (
    <div 
        onClick={onClick}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className={`${getNodeStyles()} group`}
        id={`agent-node-${agent.id}`} // ID used for connection drawing
    >
        {/* Hover Tooltip / Hovercard */}
        {isHovered && (
            <div className="absolute -top-24 left-1/2 -translate-x-1/2 z-50 w-56 bg-slate-950 border border-slate-700 rounded-xl p-3 shadow-2xl animate-in fade-in slide-in-from-bottom-2 duration-200 pointer-events-none">
                <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-white truncate pr-2">{agent.orisa?.name || agent.role}</span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded uppercase tracking-wider font-bold border ${
                        agent.status === AgentStatus.ERROR ? 'bg-red-500/20 text-red-400 border-red-500/30' : 
                        agent.status === AgentStatus.COMPLETED ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                        'bg-slate-800 text-slate-400 border-slate-700'
                    }`}>
                        {agent.status}
                    </span>
                </div>
                <div className="text-[10px] text-slate-400 mb-2 font-mono leading-tight line-clamp-2">
                    {agent.taskDescription}
                </div>
                {agent.currentAction && (
                    <div className="text-[10px] text-cyan-400 bg-cyan-950/30 px-2 py-1 rounded border border-cyan-900/50 truncate font-mono">
                        > {agent.currentAction}
                    </div>
                )}
                
                {/* Arrow */}
                <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-slate-950 border-b border-r border-slate-700 rotate-45 transform"></div>
            </div>
        )}

        {/* Interactive Hint */}
        <div className={`absolute -top-2 -right-2 bg-slate-800 text-white p-1.5 rounded-full shadow-lg transform transition-all duration-300 z-10 flex items-center justify-center border border-slate-600
            ${isSelected ? 'scale-100 opacity-100 rotate-0' : 'scale-0 opacity-0 -rotate-90 group-hover:scale-90 group-hover:opacity-80'}
        `}>
            <MousePointerClick size={12} />
        </div>
        
        {/* Selection Corners */}
        {isSelected && (
          <>
            <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-white rounded-tl opacity-60" />
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-white rounded-br opacity-60" />
          </>
        )}

        {/* Status Indicator Dot */}
        <div className={`absolute top-4 right-4 w-2 h-2 rounded-full transition-colors duration-500 
            ${agent.status === AgentStatus.ERROR ? 'bg-red-500' : 
              agent.status === AgentStatus.COMPLETED ? 'bg-emerald-500' :
              (agent.status === AgentStatus.WORKING || agent.status === AgentStatus.THINKING) ? 'bg-white animate-ping' : 'bg-slate-600'}
        `} />

        <div className="flex items-center gap-3 mb-3">
            <div className={`relative p-3 rounded-lg border border-white/10 overflow-hidden bg-black/20`}>
                {/* Background Glow for active states */}
                {(agent.status === AgentStatus.THINKING || agent.status === AgentStatus.WORKING) && (
                    <div className={`absolute inset-0 opacity-40 blur-md scale-150 animate-pulse bg-white`} />
                )}
                <div className="relative z-10">
                    {getStatusIcon()}
                </div>
            </div>
            <div>
                <div className="flex items-center gap-2">
                    <h3 className="font-bold text-lg leading-none text-white tracking-wide">{agent.orisa?.name || agent.role}</h3>
                    {agent.id === 'esu' && <span className="text-[10px] bg-red-900/50 border border-red-500/30 text-red-200 px-1 rounded">ORCHESTRATOR</span>}
                    {agent.id === 'obatala' && <span className="text-[10px] bg-slate-100/20 border border-white/30 text-white px-1 rounded">CREATOR</span>}
                </div>
                <p className="text-xs opacity-80 font-mono mt-1">{agent.role}</p>
            </div>
        </div>

        <div className="space-y-2">
            <div className="flex items-center gap-1 text-[10px] opacity-60 uppercase tracking-wider font-bold">
                <Sparkles size={10} />
                {agent.orisa?.domain}
            </div>
            
            <p className="text-xs opacity-70 line-clamp-2 h-8 leading-relaxed transition-colors">
                {agent.taskDescription}
            </p>
            
            {/* Current Action / Progress Bar Effect */}
            <div className={`relative h-8 rounded overflow-hidden border transition-all duration-500 bg-black/20 border-white/5
                 ${agent.currentAction && agent.status !== AgentStatus.COMPLETED 
                    ? 'opacity-100' 
                    : 'opacity-50'}
            `}>
                 {/* Animated background for thinking/working */}
                 {(agent.status === AgentStatus.THINKING || agent.status === AgentStatus.WORKING) && (
                    <div className={`absolute inset-0 opacity-20 animate-pulse bg-white`} />
                 )}
                 
                 <div className="absolute inset-0 p-2 flex items-center">
                    <p className={`text-[10px] font-mono truncate opacity-90`}>
                        {agent.currentAction ? `> ${agent.currentAction}` : ''}
                    </p>
                 </div>
            </div>
        </div>
    </div>
  );
};
