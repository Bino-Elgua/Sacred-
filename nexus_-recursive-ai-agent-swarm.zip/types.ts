
export enum AgentStatus {
  IDLE = 'IDLE',
  THINKING = 'THINKING', // Planning or decomposing
  WORKING = 'WORKING', // Executing specific task
  RECOVERING = 'RECOVERING', // Self-correcting errors
  WAITING = 'WAITING', // Waiting for sub-agents
  AUDITING = 'AUDITING', // QA and Security Review
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR',
}

export interface AgentTask {
  id: string;
  role: string;
  description: string;
  output?: string;
}

export interface OrisaIdentity {
    name: string;
    domain: string;
    colors: string; // Tailwind classes
    description: string;
}

export interface OrisaCustomConfig {
  orisaName: string;
  customSystemPrompt?: string;
  model?: string;
  modelVariant?: string; // e.g., 'pro', 'flash', 'ultra'
  temperature?: number;
  guardrails?: string[];
  knowledgeContext?: string; // Specific context/RAG instructions
  allowedTools?: string[]; // IDs of tools this agent can use
  deepThinkEnabled?: boolean;
  voiceSettings?: {
      voiceId: string;
      stability: number;
      similarityBoost: number;
  };
  avatarSettings?: {
      imageUrl?: string;
      stylePrompt?: string;
  };
  webhookTriggers?: {
      event: string;
      endpoint: string;
      enabled: boolean;
  }[];
}

export interface Agent {
  id: string;
  role: string; // The specific job title (e.g. "Frontend Dev")
  orisa: OrisaIdentity; // The Archetype (e.g. "Ogun")
  status: AgentStatus;
  currentAction: string; // Text description of what it's doing
  taskDescription: string;
  filename?: string; // The specific file this agent is working on
  language?: string; // The programming language
  parentId: string | null;
  output: string | null;
  errorMessage?: string; // Specific error details if failed
  color: string; // For UI distinction (legacy, mapping to orisa.colors)
}

export interface AgentMessage {
    id: string;
    fromAgentId: string;
    toAgentId: string;
    content: string;
    timestamp: number;
    type: 'query' | 'data' | 'directive';
}

export interface LogMessage {
  id: string;
  timestamp: number;
  agentId: string;
  agentRole: string;
  message: string;
  type: 'info' | 'success' | 'error' | 'system' | 'debug' | 'warning';
}

export interface DecomposedTask {
  role: string;
  orisa_archetype: string;
  task_description: string;
  filename?: string;
  language?: string;
  dependencies?: string[];
}

export interface ProjectArtifact {
  name: string; // filename or folder name
  type: 'file' | 'folder';
  content?: string;
  children?: ProjectArtifact[];
  language?: string;
}

// --- New Types for Command Center ---

export type View = 'swarm' | 'knowledge' | 'tools' | 'settings' | 'logs' | 'forge';

export type LLMProvider = 'gemini' | 'openai' | 'anthropic' | 'custom';

export interface LLMConfig {
  provider: LLMProvider;
  apiKey: string;
  model: string;
  temperature: number;
  endpoint?: string;
  customHeaders?: string;
}

export interface RagConfig {
  sourceType: 'document' | 'vector_db';
  path: string; // File path or DB Connection URL
  collection?: string; // For Vector DB
}

export interface Tool {
  id: string;
  name: string;
  type: 'webhook' | 'api' | 'rag' | 'function';
  description: string;
  endpoint?: string;
  headers?: Record<string, string>;
  enabled: boolean;
  ragConfig?: RagConfig;
}

export interface AppSettings {
  llm: LLMConfig;
  tools: Tool[];
  autoSave: boolean;
  debugMode: boolean;
  narratorEnabled: boolean; // New setting
  elevenLabsApiKey?: string; // New setting for TTS
  // New Settings
  maxConcurrentAgents: number;
  contextWindowSize: number; // in tokens
  voiceDefaults: {
      voiceId: string;
      stability: number;
  };
}

export interface StoredFile {
  id: string;
  title: string;
  content: string;
  type: 'report' | 'code' | 'log' | 'archive';
  tags: string[];
  createdAt: number;
  agentCount?: number;
  folder?: string; // Virtual folder path
  sessionId?: string; // To group files by run
}

// --- Simulator Types ---
export interface ChatMessage {
    id: string;
    role: 'user' | 'model';
    content: string;
    timestamp: number;
}
